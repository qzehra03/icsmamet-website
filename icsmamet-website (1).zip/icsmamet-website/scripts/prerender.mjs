/**
 * Prerender every route to static HTML after `vite build`.
 *  - dist/index.html, dist/<route>/index.html, dist/404.html
 *  - per-page <title>, description, canonical, Open Graph, JSON-LD
 *  - sitemap.xml and robots.txt
 * Hosting stays fully static (Netlify, Vercel, GitHub Pages, any web server).
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dist = path.join(root, 'dist');
const ssrDir = path.join(root, 'dist-ssr');

function resolveSiteUrl() {
  const raw =
    process.env.SITE_URL ||
    process.env.URL || // Netlify production URL
    (process.env.VERCEL_PROJECT_PRODUCTION_URL ? `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}` : '');
  if (!raw) return null;
  try {
    const u = new URL(raw);
    return u.origin;
  } catch {
    console.warn(`[prerender] Ignoring invalid SITE_URL: ${raw}`);
    return null;
  }
}

const esc = (s) =>
  String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const ssrEntry = (await fs.readdir(ssrDir)).find((f) => /^entry-server\.(m?js)$/.test(f));
if (!ssrEntry) throw new Error('SSR bundle not found in dist-ssr/');
const { render, pages, notFoundMeta, eventJsonLd } = await import(pathToFileURL(path.join(ssrDir, ssrEntry)).href);

const template = await fs.readFile(path.join(dist, 'index.html'), 'utf8');
const siteUrl = resolveSiteUrl();
const abs = (p) => (siteUrl ? siteUrl + p : p);

function head(meta, { isHome, noindex }) {
  const url = abs(meta.path);
  const tags = [
    `<title>${esc(meta.title)}</title>`,
    `<meta name="description" content="${esc(meta.description)}" />`,
    noindex ? `<meta name="robots" content="noindex" />` : `<link rel="canonical" href="${esc(url)}" />`,
    `<meta property="og:type" content="website" />`,
    `<meta property="og:site_name" content="ICSMAMET 2027" />`,
    `<meta property="og:locale" content="en_IN" />`,
    `<meta property="og:title" content="${esc(meta.title)}" />`,
    `<meta property="og:description" content="${esc(meta.description)}" />`,
    `<meta property="og:url" content="${esc(url)}" />`,
    `<meta property="og:image" content="${esc(abs('/og-image.png'))}" />`,
    `<meta property="og:image:width" content="1200" />`,
    `<meta property="og:image:height" content="630" />`,
    `<meta property="og:image:alt" content="ICSMAMET 2027 — 21–23 July 2027, VNR VJIET, Hyderabad" />`,
    `<meta name="twitter:card" content="summary_large_image" />`,
    `<meta name="twitter:title" content="${esc(meta.title)}" />`,
    `<meta name="twitter:description" content="${esc(meta.description)}" />`,
    `<meta name="twitter:image" content="${esc(abs('/og-image.png'))}" />`,
  ];
  if (isHome) {
    tags.push(
      `<script type="application/ld+json">${JSON.stringify(eventJsonLd(siteUrl)).replace(/</g, '\\u003c')}</script>`,
    );
  }
  return tags.join('\n    ');
}

function page(url, meta, opts) {
  const html = render(url);
  const out = template
    .replace(/<!--head-->[\s\S]*?<!--\/head-->/, head(meta, opts))
    .replace('<!--app-->', html);
  if (out.includes('<!--app-->') || out.includes('<!--head-->')) throw new Error(`Placeholder not replaced for ${url}`);
  return out;
}

for (const meta of pages) {
  const file = meta.path === '/' ? path.join(dist, 'index.html') : path.join(dist, meta.path.slice(1), 'index.html');
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, page(meta.path, meta, { isHome: meta.path === '/' }));
  console.log(`[prerender] ${meta.path.padEnd(18)} → ${path.relative(root, file)}`);
}

await fs.writeFile(path.join(dist, '404.html'), page('/404-not-found', notFoundMeta, { noindex: true }));
console.log('[prerender] 404               → dist/404.html');

const robots = ['User-agent: *', 'Allow: /'];
if (siteUrl) {
  const today = new Date().toISOString().slice(0, 10);
  const urls = pages
    .map((p) => `  <url><loc>${siteUrl}${p.path}</loc><lastmod>${today}</lastmod><priority>${p.path === '/' ? '1.0' : '0.8'}</priority></url>`)
    .join('\n');
  await fs.writeFile(
    path.join(dist, 'sitemap.xml'),
    `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`,
  );
  robots.push('', `Sitemap: ${siteUrl}/sitemap.xml`);
  console.log(`[prerender] sitemap.xml for ${siteUrl}`);
} else {
  console.warn('[prerender] SITE_URL not set — canonical URLs are relative and sitemap.xml was skipped.');
}
await fs.writeFile(path.join(dist, 'robots.txt'), robots.join('\n') + '\n');
await fs.rm(ssrDir, { recursive: true, force: true });
console.log('[prerender] done');
