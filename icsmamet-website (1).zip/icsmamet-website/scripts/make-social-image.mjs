/**
 * Regenerates public/og-image.png (1200×630) and public/apple-touch-icon.png (180×180)
 * from HTML, using the site's own fonts and microstructure artwork.
 * Requires a Chromium binary:  CHROME_PATH=/path/to/chrome node scripts/make-social-image.mjs
 */
import { chromium } from 'playwright-core';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const f = (p) => pathToFileURL(path.join(root, p)).href;
const executablePath = process.env.CHROME_PATH || undefined;

const fonts = `
@font-face{font-family:Serif;src:url(${f('node_modules/@fontsource-variable/source-serif-4/files/source-serif-4-latin-opsz-normal.woff2')}) format('woff2');font-weight:200 900}
@font-face{font-family:Sans;src:url(${f('node_modules/@fontsource/ibm-plex-sans/files/ibm-plex-sans-latin-400-normal.woff2')})}
@font-face{font-family:Mono;src:url(${f('node_modules/@fontsource/ibm-plex-mono/files/ibm-plex-mono-latin-500-normal.woff2')})}`;

const og = `<!doctype html><html><head><style>${fonts}
*{margin:0;box-sizing:border-box}
body{width:1200px;height:630px;background:#0f3b2e;color:#f3efe4;font-family:Sans;position:relative;overflow:hidden}
.tex{position:absolute;inset:0;background:url(${f('public/images/research/microstructure.svg')}) center/cover;opacity:.26;
-webkit-mask-image:linear-gradient(100deg,transparent 35%,#000 90%)}
.in{position:absolute;inset:72px 80px;display:flex;flex-direction:column}
.k{font-family:Mono;font-size:20px;letter-spacing:.16em;text-transform:uppercase;color:#d8be7c}
.a{margin-top:40px;font-family:Serif;font-weight:620;font-size:96px;letter-spacing:.01em;line-height:1}
.a span{color:#d8be7c;font-weight:480}
.n{margin-top:26px;max-width:860px;font-family:Serif;font-size:34px;line-height:1.28;color:#f3efe4}
.b{margin-top:auto;display:flex;gap:28px;align-items:center;font-size:24px;color:#c3cdc6;border-top:1px solid rgba(216,190,124,.45);padding-top:26px}
.b strong{color:#f3efe4;font-weight:400}
</style></head><body><div class="tex"></div><div class="in">
<div class="k">International Conference</div>
<div class="a">ICSMAMET <span>2027</span></div>
<div class="n">Sustainable Materials, Advanced Manufacturing and Emerging Technologies</div>
<div class="b"><strong>21–23 July 2027</strong><span>·</span><span>VNR VJIET, Hyderabad, India</span></div>
</div></body></html>`;

const icon = `<!doctype html><html><head><style>*{margin:0}body{width:180px;height:180px;background:#0f3b2e}</style></head><body>
${(await fs.readFile(path.join(root, 'public/favicon.svg'), 'utf8')).replace('<svg ', '<svg width="180" height="180" ').replace('rx="8"', 'rx="0"')}
</body></html>`;

const browser = await chromium.launch({ executablePath });
const page = await browser.newPage({ viewport: { width: 1200, height: 630 } });
// Load from a file:// URL so local fonts and artwork are allowed to load.
const tmp = path.join(root, 'node_modules', '.tmp');
await fs.mkdir(tmp, { recursive: true });
await fs.writeFile(path.join(tmp, 'og.html'), og);
await page.goto(pathToFileURL(path.join(tmp, 'og.html')).href, { waitUntil: 'load' });
await page.evaluate(() => document.fonts.ready);
await page.screenshot({ path: path.join(root, 'public/og-image.png') });
await page.setViewportSize({ width: 180, height: 180 });
await page.setContent(icon);
await page.screenshot({ path: path.join(root, 'public/apple-touch-icon.png') });
await browser.close();
console.log('Wrote public/og-image.png and public/apple-touch-icon.png');
