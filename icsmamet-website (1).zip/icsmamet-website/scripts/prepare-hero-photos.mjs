/**
 * Optimizes campus photos for the homepage slideshow.
 *
 *   1. Put original photos (JPG/PNG/WebP/HEIC-converted) in ./photos-to-add/
 *   2. Run:  npm run photos
 *   3. Each photo becomes public/images/campus/hero-<name>-1280.webp, -1920.webp, -1920.jpg
 *   4. Add an entry for each one in src/data/heroSlides.ts (the script prints them).
 */
import sharp from 'sharp';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const inDir = path.join(root, 'photos-to-add');
const outDir = path.join(root, 'public/images/campus');
await fs.mkdir(outDir, { recursive: true });

const files = (await fs.readdir(inDir)).filter((f) => /\.(jpe?g|png|webp|tiff?)$/i.test(f)).sort();
if (!files.length) {
  console.log('No photos found in photos-to-add/.');
  process.exit(0);
}

const slug = (f) =>
  path.parse(f).name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'photo';

const entries = [];
for (const f of files) {
  const name = `hero-${slug(f)}`;
  const input = sharp(path.join(inDir, f)).rotate(); // respect camera orientation
  const meta = await input.metadata();
  // Orientation-corrected source size
  const [sw, sh] = (meta.orientation ?? 1) >= 5 ? [meta.height ?? 0, meta.width ?? 0] : [meta.width ?? 0, meta.height ?? 0];
  for (const target of [1280, 1920]) {
    // Crop to 16:9 without enlarging small originals (upscaling only adds bytes).
    let w = Math.min(target, sw);
    let h = Math.round((w * 9) / 16);
    if (h > sh) {
      h = sh;
      w = Math.round((h * 16) / 9);
    }
    const resized = input.clone().resize({ width: w, height: h, fit: 'cover', position: 'attention' });
    await resized.clone().webp({ quality: 78 }).toFile(path.join(outDir, `${name}-${target}.webp`));
    if (target === 1920) await resized.clone().jpeg({ quality: 80, progressive: true, mozjpeg: true }).toFile(path.join(outDir, `${name}-${target}.jpg`));
  }
  if ((meta.width ?? 0) < 1600) console.warn(`  ! ${f} is only ${meta.width}px wide — it may look soft full-screen.`);
  entries.push(`  {\n    base: '/images/campus/${name}',\n    alt: 'Describe what the photo shows',\n    caption: 'Short caption',\n  },`);
  console.log(`✓ ${f} → public/images/campus/${name}-{1280,1920}.webp/.jpg`);
}
console.log('\nAdd these to heroSlides in src/data/heroSlides.ts:\n');
console.log(entries.join('\n'));
