/**
 * End-to-end smoke test against the production build (run `npm run build` first).
 * Checks every route on desktop and mobile for: HTTP status, console/hydration
 * errors, a single <h1>, horizontal overflow, broken internal links and anchors,
 * broken images, axe-core accessibility violations, plus the mobile menu and
 * form fallbacks.
 *   CHROME_PATH=/path/to/chrome npm run test:e2e   [SCREENSHOTS=dir]
 */
import { chromium } from 'playwright-core';
import { spawn } from 'node:child_process';
import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PORT = 4321;
const BASE = `http://localhost:${PORT}`;
const routes = ['/', '/about', '/themes', '/speakers', '/committees', '/registration', '/accommodation', '/important-dates', '/contact'];
const viewports = { desktop: { width: 1440, height: 900 }, tablet: { width: 820, height: 1180 }, mobile: { width: 390, height: 844 } };
const shotDir = process.env.SCREENSHOTS;
const axeSource = await fs.readFile(require.resolve('axe-core/axe.min.js'), 'utf8');

const failures = [];
const fail = (msg) => {
  failures.push(msg);
  console.log(`  ✗ ${msg}`);
};
const ok = (msg) => console.log(`  ✓ ${msg}`);

const server = spawn(process.execPath, [path.join(root, 'scripts/serve.mjs')], { env: { ...process.env, PORT: String(PORT) }, stdio: 'ignore' });
await new Promise((r) => setTimeout(r, 600));

const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || undefined });
try {
  // 1. Every route × viewport
  const internalLinks = new Set();
  for (const [vpName, viewport] of Object.entries(viewports)) {
    const ctx = await browser.newContext({ viewport });
    // Block third-party requests (map embed) so tests are deterministic offline.
    await ctx.route(/^https?:\/\/(?!localhost)/, (r) => r.abort());
    for (const route of routes) {
      const page = await ctx.newPage();
      const errors = [];
      page.on('console', (m) => {
        if (m.type() === 'error' && !/net::ERR_FAILED|ERR_BLOCKED|Failed to load resource/.test(m.text())) errors.push(m.text());
      });
      page.on('pageerror', (e) => errors.push(String(e)));
      const res = await page.goto(BASE + route, { waitUntil: 'networkidle' });
      console.log(`[${vpName}] ${route}`);
      if (res.status() !== 200) fail(`${route} returned ${res.status()}`);
      const prerendered = await page.evaluate(() => document.querySelector('#root')?.getAttribute('data-x') === null);
      if (!prerendered) fail('root missing');
      if (errors.length) fail(`${vpName} ${route} console errors: ${errors.join(' | ')}`);
      const h1 = await page.locator('h1').count();
      if (h1 !== 1) fail(`${route} has ${h1} <h1> elements`);
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
      if (overflow > 1) fail(`${vpName} ${route} horizontal overflow ${overflow}px`);
      const badImgs = await page.evaluate(async () => {
        const imgs = [...document.images];
        for (const img of imgs) {
          img.loading = 'eager';
          if (!img.complete) await new Promise((r) => { img.onload = img.onerror = r; });
        }
        return imgs.filter((i) => !i.naturalWidth).map((i) => i.currentSrc || i.src);
      });
      if (badImgs.length) fail(`${route} broken images: ${badImgs.join(', ')}`);
      const title = await page.title();
      if (vpName === 'desktop') {
        const desc = await page.getAttribute('meta[name="description"]', 'content');
        if (!title || !desc) fail(`${route} missing title/description`);
      }
      if (vpName === 'desktop') {
        const hrefs = await page.$$eval('a[href]', (as) => as.map((a) => a.getAttribute('href')));
        hrefs.filter((h) => h.startsWith('/') || h.startsWith('#')).forEach((h) => internalLinks.add(h.startsWith('#') ? route + h : h));
      }
      {
        // axe accessibility audit
        await page.addScriptTag({ content: axeSource });
        const axe = await page.evaluate(async () => {
          // @ts-ignore
          const r = await window.axe.run(document, { runOnly: ['wcag2a', 'wcag2aa', 'wcag21aa', 'best-practice'] });
          return r.violations.map((v) => `${v.id} (${v.impact}) ×${v.nodes.length}: ${v.nodes.slice(0, 2).map((n) => n.target.join(' ')).join(' ; ')}`);
        });
        if (axe.length) axe.forEach((v) => fail(`axe ${route}: ${v}`));
        else if (vpName === 'desktop') ok(`axe: no violations · "${title}"`);
      }
      if (shotDir) {
        await fs.mkdir(shotDir, { recursive: true });
        const name = `${vpName}${route === '/' ? '-home' : route.replace(/\//g, '-')}.png`;
        await page.screenshot({ path: path.join(shotDir, name), fullPage: true });
      }
      await page.close();
    }
    await ctx.close();
  }

  // 2. Internal links and anchors
  console.log(`[links] checking ${internalLinks.size} internal links`);
  const ctx = await browser.newContext({ viewport: viewports.desktop });
  await ctx.route(/^https?:\/\/(?!localhost)/, (r) => r.abort());
  const page = await ctx.newPage();
  for (const href of internalLinks) {
    const [p, hash] = href.split('#');
    const res = await page.goto(BASE + (p || '/'), { waitUntil: 'domcontentloaded' });
    if (res.status() !== 200) fail(`link ${href} → ${res.status()}`);
    if (hash && hash !== 'top' && hash !== 'main' && !(await page.$(`[id="${hash}"]`))) fail(`anchor missing: ${href}`);
  }
  ok('internal links checked');

  // 3. 404 page
  const r404 = await page.goto(BASE + '/no-such-page', { waitUntil: 'load' });
  if (r404.status() !== 404) fail(`unknown route returned ${r404.status()}`);
  if (!(await page.getByRole('heading', { name: 'Page not found' }).count())) fail('404 page heading missing');
  else ok('404 page served with status 404');

  // 4. Client-side navigation + focus management
  await page.goto(BASE + '/', { waitUntil: 'load' });
  await page.getByRole('navigation', { name: 'Primary' }).getByRole('link', { name: 'Committees' }).click();
  await page.waitForURL('**/committees');
  const focused = await page.evaluate(() => document.activeElement?.id);
  if (focused !== 'page-title') fail(`focus after navigation on ${focused}`);
  if (!(await page.title()).startsWith('Committees')) fail('title not updated on client navigation');
  else ok('client navigation updates title and focuses <h1>');
  await page.goto(BASE + '/', { waitUntil: 'load' });
  await page.locator('a[href="/themes#track-2"]').first().click();
  await page.waitForURL('**/themes#track-2');
  await page.waitForTimeout(1500); // allow smooth scrolling to finish
  const top = await page.evaluate(() => document.getElementById('track-2').getBoundingClientRect().top);
  if (top < 0 || top > 200) fail(`hash navigation scroll position off (${top})`);
  else ok('cross-page hash link scrolls to target');

  // 5. Mobile menu
  const m = await browser.newContext({ viewport: viewports.mobile });
  await m.route(/^https?:\/\/(?!localhost)/, (r) => r.abort());
  const mp = await m.newPage();
  await mp.goto(BASE + '/', { waitUntil: 'load' });
  const toggle = mp.locator('.menu-toggle');
  await toggle.click();
  if ((await toggle.getAttribute('aria-expanded')) !== 'true') fail('menu aria-expanded not true');
  if (!(await mp.locator('#mobile-menu').isVisible())) fail('mobile menu not visible');
  await mp.keyboard.press('Escape');
  if (await mp.locator('#mobile-menu').isVisible()) fail('Esc did not close the menu');
  await mp.getByRole('button', { name: 'Menu' }).click();
  await mp.locator('#mobile-menu').getByRole('link', { name: /Registration/ }).first().click();
  await mp.waitForURL('**/registration');
  if (await mp.locator('#mobile-menu').isVisible()) fail('menu did not close after navigation');
  else ok('mobile menu opens, closes on Esc and on navigation');

  // 6. Forms: validation + mailto fallback
  await mp.goto(BASE + '/contact', { waitUntil: 'load' });
  await mp.getByRole('button', { name: /Send message/ }).click();
  const errs = await mp.locator('.field__error').count();
  if (errs < 4) fail(`contact form showed ${errs} validation errors (expected 4)`);
  const active = await mp.evaluate(() => document.activeElement?.getAttribute('name'));
  if (active !== 'name') fail('focus not moved to first invalid field');
  await mp.getByLabel('Full name').fill('Test Author');
  await mp.getByLabel('Email').fill('author@example.org');
  await mp.getByLabel('Topic').selectOption('Registration');
  await mp.getByRole('textbox', { name: 'Message' }).fill('Question about student registration.');
  await mp.evaluate(() => {
    // Capture the mailto navigation instead of leaving the page.
    window.__mailto = null;
    const desc = Object.getOwnPropertyDescriptor(window.Location.prototype, 'href');
    Object.defineProperty(window.location, 'href', { set: (v) => (window.__mailto = v), get: () => desc.get.call(window.location) });
  }).catch(() => {});
  await mp.getByRole('button', { name: /Send message/ }).click();
  await mp.waitForSelector('.form__status .notice');
  const link = await mp.locator('.form__status a').getAttribute('href');
  if (!link?.startsWith('mailto:sahithi_vvd@vnrvjiet.in,srilatha_n@vnrvjiet.in?subject=ICSMAMET%202027')) fail(`unexpected mailto: ${link}`);
  else if (!decodeURIComponent(link).includes('Topic: Registration')) fail('mailto body missing fields');
  else ok('contact form validates and builds pre-filled mailto to both conveners');

  await mp.goto(BASE + '/accommodation', { waitUntil: 'load' });
  await mp.getByLabel('Full name').fill('Guest');
  await mp.getByLabel('Email').fill('guest@example.org');
  await mp.getByLabel('Accommodation preference').selectOption('Either');
  await mp.getByLabel('Arrival date').fill('2027-07-22');
  await mp.getByLabel('Departure date').fill('2027-07-20');
  await mp.getByRole('button', { name: /Send accommodation request/ }).click();
  if (!(await mp.getByText('Must be on or after the arrival date.').count())) fail('departure-before-arrival not caught');
  else ok('accommodation form validates date order');

  // 7. Dark theme: device preference, toggle, persistence, and axe in dark mode
  const d = await browser.newContext({ viewport: viewports.desktop, colorScheme: 'dark' });
  await d.route(/^https?:\/\/(?!localhost)/, (r) => r.abort());
  const dp = await d.newPage();
  await dp.goto(BASE + '/', { waitUntil: 'load' });
  if ((await dp.getAttribute('html', 'data-theme')) !== 'dark') fail('dark device setting not applied');
  for (const route of routes) {
    await dp.goto(BASE + route, { waitUntil: 'load' });
    await dp.addScriptTag({ content: axeSource });
    const v = await dp.evaluate(async () => {
      // @ts-ignore
      const r = await window.axe.run(document, { runOnly: ['wcag2a', 'wcag2aa', 'wcag21aa'] });
      return r.violations.map((x) => `${x.id} ×${x.nodes.length}: ${x.nodes.slice(0, 3).map((n) => n.target.join(' ')).join(' ; ')}`);
    });
    v.forEach((x) => fail(`axe dark ${route}: ${x}`));
  }
  await dp.goto(BASE + '/', { waitUntil: 'load' });
  await dp.click('.theme-toggle');
  if ((await dp.getAttribute('html', 'data-theme')) !== 'light') fail('toggle did not switch to light');
  await dp.reload({ waitUntil: 'load' });
  if ((await dp.getAttribute('html', 'data-theme')) !== 'light') fail('theme choice not remembered after reload');
  else ok('dark theme follows device, passes axe, toggles and persists');
  await d.close();

  // 8. Calendar download
  await mp.goto(BASE + '/important-dates', { waitUntil: 'load' });
  const ics = decodeURIComponent((await mp.locator('a[download="icsmamet-2027.ics"]').getAttribute('href')).split(',')[1]);
  if (!ics.includes('DTSTART;VALUE=DATE:20270721') || !ics.includes('DTEND;VALUE=DATE:20270724')) fail('ics dates wrong');
  else ok('.ics calendar file has correct dates');
  await m.close();
  await ctx.close();
} finally {
  await browser.close();
  server.kill();
}

console.log(failures.length ? `\n${failures.length} check(s) failed.` : '\nAll checks passed.');
process.exit(failures.length ? 1 : 0);
