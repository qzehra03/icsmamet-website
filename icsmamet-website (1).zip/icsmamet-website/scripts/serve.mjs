/**
 * Minimal static server that mimics Netlify/Vercel behaviour for local checks:
 * /about → dist/about/index.html, unknown paths → dist/404.html (status 404).
 * Usage: npm run preview  [PORT=4173]
 */
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const dist = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'dist');
const port = Number(process.env.PORT || 4173);
const types = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.woff2': 'font/woff2', '.woff': 'font/woff',
  '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.txt': 'text/plain', '.xml': 'application/xml',
  '.ico': 'image/x-icon', '.pdf': 'application/pdf',
};

function resolve(urlPath) {
  const clean = decodeURIComponent(urlPath.split('?')[0]).replace(/\/+$/, '') || '/';
  const candidates = [path.join(dist, clean), path.join(dist, clean, 'index.html'), path.join(dist, clean + '.html')];
  for (const c of candidates) {
    if (!c.startsWith(dist)) continue;
    try {
      if (fs.statSync(c).isFile()) return c;
    } catch {}
  }
  return null;
}

http
  .createServer((req, res) => {
    const file = resolve(req.url || '/');
    const target = file ?? path.join(dist, '404.html');
    res.writeHead(file ? 200 : 404, { 'Content-Type': types[path.extname(target)] || 'application/octet-stream' });
    fs.createReadStream(target).pipe(res);
  })
  .listen(port, () => console.log(`Serving dist/ at http://localhost:${port}`));
