import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { navPages } from '../app/siteMap';
import { conference } from '../data/conference';
import { BrandMark } from './BrandMark';
import { Icon } from './Icon';
import { ThemeToggle } from './ThemeToggle';

export function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const toggleRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  // Close the menu whenever the route changes.
  useEffect(() => setOpen(false), [location.pathname]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Mobile menu: Esc closes, focus stays inside the panel, page doesn't scroll behind it.
  useEffect(() => {
    if (!open) return;
    const panel = panelRef.current;
    const first = panel?.querySelector<HTMLElement>('a, button');
    first?.focus();
    document.body.classList.add('menu-open');

    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpen(false);
        toggleRef.current?.focus();
      }
      if (e.key === 'Tab' && panel) {
        const items = Array.from(panel.querySelectorAll<HTMLElement>('a, button'));
        const focusables = [toggleRef.current!, ...items];
        const idx = focusables.indexOf(document.activeElement as HTMLElement);
        if (e.shiftKey && idx <= 0) {
          e.preventDefault();
          focusables[focusables.length - 1].focus();
        } else if (!e.shiftKey && idx === focusables.length - 1) {
          e.preventDefault();
          focusables[0].focus();
        }
      }
    };
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.classList.remove('menu-open');
    };
  }, [open]);

  return (
    <header className={`site-header${scrolled ? ' is-scrolled' : ''}${open ? ' is-open' : ''}`}>
      <div className="container site-header__inner">
        <Link to="/" className="brand" aria-label={`${conference.shortName} — home`}>
          <BrandMark size={40} />
          <span className="brand__text">
            <span className="brand__name">
              {conference.acronym} <span className="brand__year">{conference.edition}</span>
            </span>
            <span className="brand__meta">
              {conference.dates.display} · {conference.host.short}, {conference.host.city}
            </span>
          </span>
        </Link>

        <nav className="primary-nav" aria-label="Primary">
          <ul>
            {navPages.map((p) => (
              <li key={p.path}>
                <NavLink to={p.path}>{p.label}</NavLink>
              </li>
            ))}
          </ul>
        </nav>

        <ThemeToggle />

        <button
          ref={toggleRef}
          type="button"
          className="menu-toggle"
          aria-expanded={open}
          aria-controls="mobile-menu"
          onClick={() => setOpen((v) => !v)}
        >
          <Icon name={open ? 'close' : 'menu'} size={22} />
          <span className="menu-toggle__label">{open ? 'Close' : 'Menu'}</span>
        </button>
      </div>

      <div
        id="mobile-menu"
        ref={panelRef}
        className="mobile-menu"
        hidden={!open}
      >
        <nav aria-label="Mobile">
          <ul>
            <li>
              <NavLink to="/" end>
                <span className="mobile-menu__num">00</span> Home
              </NavLink>
            </li>
            {navPages.map((p) => (
              <li key={p.path}>
                <NavLink to={p.path}>
                  <span className="mobile-menu__num">{p.number}</span> {p.label}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
        <div className="mobile-menu__footer">
          <p>
            {conference.dates.display}
            <br />
            {conference.venueLine}
          </p>
        </div>
      </div>
    </header>
  );
}
