import { Link } from 'react-router-dom';
import { navPages } from '../app/siteMap';
import { conference } from '../data/conference';
import { contacts } from '../data/contact';
import { maps } from '../services/registrationService';
import { BrandMark } from './BrandMark';
import { Icon } from './Icon';

export function Footer() {
  return (
    <footer className="site-footer">
      <div className="container site-footer__grid">
        <div className="site-footer__identity">
          <Link to="/" className="brand brand--footer" aria-label={`${conference.shortName} — home`}>
            <BrandMark size={44} />
            <span className="brand__text">
              <span className="brand__name">
                {conference.acronym} <span className="brand__year">{conference.edition}</span>
              </span>
            </span>
          </Link>
          <p className="site-footer__name">{conference.name}</p>
          <p className="site-footer__when">
            <Icon name="calendar" size={16} /> {conference.dates.display}
          </p>
          <p className="site-footer__when">
            <Icon name="pin" size={16} /> {conference.venueLine}
          </p>
        </div>

        <nav className="site-footer__col" aria-label="Footer">
          <h2 className="site-footer__heading">Conference</h2>
          <ul>
            {navPages.map((p) => (
              <li key={p.path}>
                <Link to={p.path}>{p.label}</Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="site-footer__col">
          <h2 className="site-footer__heading">Conveners</h2>
          <ul className="site-footer__contacts">
            {contacts.map((c) => (
              <li key={c.email}>
                <span className="site-footer__person">{c.name}</span>
                <a href={`mailto:${c.email}`}>{c.email}</a>
                <a href={`tel:${c.phoneE164}`}>{c.phone}</a>
              </li>
            ))}
          </ul>
          <a className="link-arrow" href={maps.openUrl} target="_blank" rel="noopener noreferrer">
            Venue on Google Maps <Icon name="external" size={14} />
            <span className="visually-hidden">(opens in a new tab)</span>
          </a>
        </div>
      </div>
      <div className="container">
        <div className="site-footer__base">
        <p>
          {conference.shortName} · Hosted by {conference.host.short}, {conference.host.city}
        </p>
        <p>
          <a href="#top">Back to top ↑</a>
        </p>
        </div>
      </div>
    </footer>
  );
}
