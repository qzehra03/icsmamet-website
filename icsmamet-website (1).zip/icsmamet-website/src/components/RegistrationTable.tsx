import type { FeeGroup } from '../data/registration';

/** Semantic fee table: one table, grouped by delegate type with row headers. */
export function RegistrationTable({ groups }: { groups: FeeGroup[] }) {
  return (
    <div className="fee-table-wrap">
      <table className="fee-table">
        <caption className="visually-hidden">Registration fees by delegate type and category (regular rates)</caption>
        <thead>
          <tr>
            <th scope="col">Delegate type</th>
            <th scope="col">Category</th>
            <th scope="col" className="fee-table__amount">
              Regular
            </th>
          </tr>
        </thead>
        {groups.map((g) => (
          <tbody key={g.id}>
            {g.rows.map((r, i) => (
              <tr key={r.category}>
                {i === 0 ? (
                  <th scope="rowgroup" rowSpan={g.rows.length} className="fee-table__group">
                    <span>{g.delegateType}</span>
                    <span className="fee-table__currency">{g.currency}</span>
                  </th>
                ) : null}
                <td data-label="Category">
                  <span className="fee-table__mobile-group" aria-hidden="true">
                    {g.delegateType} · {g.currency}
                  </span>
                  {r.category}
                </td>
                <td data-label="Regular" className="fee-table__amount">
                  {r.regular}
                </td>
              </tr>
            ))}
          </tbody>
        ))}
      </table>
    </div>
  );
}
