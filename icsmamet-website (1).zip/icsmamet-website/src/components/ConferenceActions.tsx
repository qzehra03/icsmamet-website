import { Link } from 'react-router-dom';
import { getDeadline } from '../data/deadlines';
import { integrations, mailtoConveners } from '../services/registrationService';
import { Icon } from './Icon';

interface ActionProps {
  tone?: 'dark' | 'light';
  size?: 'md' | 'lg';
}

/**
 * "Submit a Paper" call to action.
 * Live link only when VITE_SUBMISSION_URL is configured; otherwise it shows the
 * verified opening date and links to the call-for-papers information instead.
 */
export function SubmitPaperAction({ tone = 'light', size = 'md' }: ActionProps) {
  const cls = `btn ${tone === 'dark' ? 'btn--gold' : 'btn--primary'}${size === 'lg' ? ' btn--lg' : ''}`;
  if (integrations.submissionUrl) {
    return (
      <a className={cls} href={integrations.submissionUrl} target="_blank" rel="noopener noreferrer">
        Submit a paper <Icon name="external" size={16} />
        <span className="visually-hidden">(opens in a new tab)</span>
      </a>
    );
  }
  const cfp = getDeadline('cfp-open');
  return (
    <Link className={cls} to="/themes#call-for-papers">
      <span className="btn__stack">
        <span>Call for papers</span>
        <span className="btn__sub">Opens {cfp.display}</span>
      </span>
      <Icon name="arrowRight" size={16} />
    </Link>
  );
}

/**
 * "Register" call to action.
 * Live link only when VITE_REGISTRATION_URL is configured; otherwise leads to the
 * fee schedule and process on the Registration page.
 */
export function RegisterAction({ tone = 'light', size = 'md' }: ActionProps) {
  const cls = `btn ${tone === 'dark' ? 'btn--outline-light' : 'btn--outline'}${size === 'lg' ? ' btn--lg' : ''}`;
  if (integrations.registrationUrl) {
    return (
      <a className={cls} href={integrations.registrationUrl} target="_blank" rel="noopener noreferrer">
        Register now <Icon name="external" size={16} />
        <span className="visually-hidden">(opens in a new tab)</span>
      </a>
    );
  }
  return (
    <Link className={cls} to="/registration">
      <span className="btn__stack">
        <span>Registration</span>
        <span className="btn__sub">Fees &amp; process</span>
      </span>
      <Icon name="arrowRight" size={16} />
    </Link>
  );
}

/** Status block used on Registration and Themes pages to explain an integration that isn't live yet. */
export function IntegrationStatus({ kind }: { kind: 'registration' | 'submission' }) {
  const live = kind === 'registration' ? integrations.registrationUrl : integrations.submissionUrl;
  if (live) {
    return (
      <div className="status status--live">
        <span className="status__dot" aria-hidden="true" />
        <div>
          <p className="status__title">
            {kind === 'registration' ? 'Online registration is open' : 'Paper submission is open'}
          </p>
          <a className="btn btn--primary" href={live} target="_blank" rel="noopener noreferrer">
            {kind === 'registration' ? 'Go to the registration form' : 'Go to the submission system'}{' '}
            <Icon name="external" size={16} />
            <span className="visually-hidden">(opens in a new tab)</span>
          </a>
        </div>
      </div>
    );
  }
  const subject =
    kind === 'registration' ? 'ICSMAMET 2027 — Registration enquiry' : 'ICSMAMET 2027 — Paper submission enquiry';
  return (
    <div className="status status--pending">
      <span className="status__dot" aria-hidden="true" />
      <div>
        <p className="status__title">
          {kind === 'registration'
            ? 'The online registration form has not been published yet'
            : `The paper submission system opens with the call for papers on ${getDeadline('cfp-open').display}`}
        </p>
        <p className="status__body">
          {kind === 'registration'
            ? 'The registration link and payment instructions will be posted on this page as soon as they are confirmed. Until then, the conveners can answer registration questions by email.'
            : 'The submission link, author guidelines and paper template will be posted here when the call opens. Until then, the conveners can answer submission questions by email.'}
        </p>
        <a className="btn btn--outline" href={mailtoConveners(subject)}>
          <Icon name="mail" size={16} /> Email the conveners
        </a>
      </div>
    </div>
  );
}
