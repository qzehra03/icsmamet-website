import { institution } from '../data/conference';

interface CampusImageProps {
  priority?: boolean;
  sizes?: string;
  className?: string;
}

/** Responsive campus photograph (WebP with JPEG fallback). */
export function CampusImage({ priority = false, sizes = '(min-width: 1200px) 640px, 100vw', className }: CampusImageProps) {
  const { base, alt, width, height } = institution.image;
  return (
    <picture className={className}>
      <source type="image/webp" srcSet={`${base}-640.webp 640w, ${base}-1024.webp 1024w, ${base}-1378.webp 1378w`} sizes={sizes} />
      <img
        src={`${base}-1378.jpg`}
        alt={alt}
        width={width}
        height={height}
        loading={priority ? 'eager' : 'lazy'}
        decoding="async"
        fetchPriority={priority ? 'high' : 'auto'}
      />
    </picture>
  );
}
