import type { ReactNode } from 'react';
import type { PageMeta } from '../app/siteMap';
import { Breadcrumbs } from './Breadcrumbs';

interface PageHeroProps {
  meta: PageMeta;
  title: ReactNode;
  lead?: ReactNode;
  aside?: ReactNode;
}

/** Inner-page header band: section number, title, lead paragraph and optional key facts. */
export function PageHero({ meta, title, lead, aside }: PageHeroProps) {
  return (
    <section className="page-hero" aria-labelledby="page-title">
      <div className="page-hero__texture" aria-hidden="true" />
      <div className="container page-hero__inner">
        <div className="page-hero__main">
          <Breadcrumbs current={meta.label} />
          <p className="eyebrow eyebrow--on-dark">
            {meta.number ? <span className="eyebrow__num">{meta.number}</span> : null}
            {meta.label}
          </p>
          <h1 id="page-title" className="page-hero__title" tabIndex={-1}>
            {title}
          </h1>
          {lead ? <div className="page-hero__lead">{lead}</div> : null}
        </div>
        {aside ? <div className="page-hero__aside">{aside}</div> : null}
      </div>
    </section>
  );
}
