import { Link } from 'react-router-dom';
import type { Track } from '../data/tracks';
import { Icon } from './Icon';
import { TrackMotif } from './TrackMotif';

interface TrackCardProps {
  track: Track;
  /** "preview" shows a few topics and links to the Themes page; "full" lists every topic. */
  variant?: 'preview' | 'full';
  previewCount?: number;
}

export function TrackCard({ track, variant = 'preview', previewCount = 5 }: TrackCardProps) {
  const topics = variant === 'preview' ? track.topics.slice(0, previewCount) : track.topics;
  const remaining = track.topics.length - topics.length;
  const headingId = `${track.id}-title${variant === 'full' ? '' : '-preview'}`;

  return (
    <article className={`track-card track-card--${variant} track-card--${track.motif}`} aria-labelledby={headingId} id={variant === 'full' ? track.id : undefined}>
      <div className="track-card__head">
        <p className="track-card__num">Track {String(track.number).padStart(2, '0')}</p>
        <TrackMotif motif={track.motif} />
      </div>
      <h3 id={headingId} className="track-card__title">
        {track.title}
      </h3>
      <p className="track-card__focus">{track.focus}</p>
      <p className="track-card__count">
        {track.topics.length} topics
      </p>
      <ul className="track-card__topics">
        {topics.map((t) => (
          <li key={t}>{t}</li>
        ))}
      </ul>
      {variant === 'preview' ? (
        <Link className="link-arrow track-card__link" to={`/themes#${track.id}`}>
          {remaining > 0 ? `All ${track.topics.length} topics` : 'View track'}
          <span className="visually-hidden"> in Track {track.number}: {track.title}</span>
          <Icon name="arrowRight" size={16} />
        </Link>
      ) : null}
    </article>
  );
}
