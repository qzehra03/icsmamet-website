import type { TrackMotif as Motif } from '../data/tracks';

/**
 * Small scientific line illustrations used to differentiate the three tracks:
 * a crystal lattice (materials), deposited layers (additive manufacturing),
 * and a node network (digital twins / AI).
 */
export function TrackMotif({ motif }: { motif: Motif }) {
  return (
    <svg viewBox="0 0 120 80" className="track-motif" aria-hidden="true" focusable="false">
      {motif === 'lattice' && <Lattice />}
      {motif === 'layers' && <Layers />}
      {motif === 'network' && <Network />}
    </svg>
  );
}

function Lattice() {
  const nodes: [number, number][] = [];
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 6; c++) {
      nodes.push([12 + c * 19 + (r % 2 ? 9.5 : 0), 12 + r * 18]);
    }
  }
  return (
    <g>
      <g stroke="currentColor" strokeWidth="1" opacity="0.5">
        {nodes.map(([x, y], i) =>
          nodes.slice(i + 1).map(([x2, y2], j) => {
            const d = Math.hypot(x2 - x, y2 - y);
            return d < 22 ? <line key={`${i}-${j}`} x1={x} y1={y} x2={x2} y2={y2} /> : null;
          }),
        )}
      </g>
      <g fill="currentColor">
        {nodes.map(([x, y], i) => (
          <circle key={i} cx={x} cy={y} r={i === 8 || i === 15 ? 3.4 : 2.2} className={i === 8 || i === 15 ? 'accent' : undefined} />
        ))}
      </g>
    </g>
  );
}

function Layers() {
  return (
    <g fill="none" stroke="currentColor" strokeWidth="1.2">
      {Array.from({ length: 9 }, (_, i) => {
        const y = 70 - i * 6.5;
        const inset = i * 3.2;
        return <path key={i} d={`M${10 + inset} ${y}H${110 - inset}`} opacity={0.35 + i * 0.07} />;
      })}
      <path d="M60 8v6" className="accent-stroke" strokeWidth="1.6" />
      <path d="M53 4h14l-4 6h-6Z" className="accent-stroke" strokeWidth="1.4" />
    </g>
  );
}

function Network() {
  const nodes: [number, number][] = [
    [14, 40], [36, 18], [36, 62], [60, 30], [60, 54], [84, 16], [84, 42], [84, 66], [106, 40],
  ];
  const edges: [number, number][] = [
    [0, 1], [0, 2], [1, 3], [2, 4], [1, 4], [2, 3], [3, 5], [3, 6], [4, 6], [4, 7], [5, 8], [6, 8], [7, 8],
  ];
  return (
    <g>
      <g stroke="currentColor" strokeWidth="1" opacity="0.5">
        {edges.map(([a, b]) => (
          <line key={`${a}-${b}`} x1={nodes[a][0]} y1={nodes[a][1]} x2={nodes[b][0]} y2={nodes[b][1]} />
        ))}
      </g>
      {nodes.map(([x, y], i) => (
        <circle
          key={i}
          cx={x}
          cy={y}
          r={i === 8 ? 4 : 3}
          fill={i === 8 ? 'currentColor' : 'var(--motif-bg, #fff)'}
          stroke="currentColor"
          strokeWidth="1.3"
          className={i === 8 ? 'accent' : undefined}
        />
      ))}
    </g>
  );
}
