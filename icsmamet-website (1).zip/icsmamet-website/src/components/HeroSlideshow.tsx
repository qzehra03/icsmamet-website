import { useCallback, useEffect, useState } from 'react';
import { heroSlides, SLIDE_SECONDS } from '../data/heroSlides';

/**
 * Full-bleed background slideshow for the homepage hero.
 * - Gentle crossfade; no movement for visitors who prefer reduced motion.
 * - Auto-advance pauses on hover/focus, when the tab is hidden, or via the
 *   Pause button (WCAG 2.2.2 — moving content can be paused).
 * - Only the first image loads eagerly; the rest load after the page is interactive.
 */
export function HeroSlideshow() {
  const count = heroSlides.length;
  const [index, setIndex] = useState(0);
  const [mounted, setMounted] = useState(false);
  const [userPaused, setUserPaused] = useState(false);
  const [hoverPaused, setHoverPaused] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    setMounted(true);
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const update = () => setReducedMotion(mq.matches);
    update();
    mq.addEventListener('change', update);
    return () => mq.removeEventListener('change', update);
  }, []);

  const playing = count > 1 && mounted && !userPaused && !hoverPaused && !reducedMotion;

  const go = useCallback((i: number) => setIndex(((i % count) + count) % count), [count]);

  useEffect(() => {
    if (!playing) return;
    let timer = window.setInterval(() => setIndex((i) => (i + 1) % count), SLIDE_SECONDS * 1000);
    const onVisibility = () => {
      window.clearInterval(timer);
      if (!document.hidden) timer = window.setInterval(() => setIndex((i) => (i + 1) % count), SLIDE_SECONDS * 1000);
    };
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      window.clearInterval(timer);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, [playing, count]);

  return (
    <div className="slideshow" aria-hidden={count < 2 ? true : undefined}>
      <div className="slideshow__frames">
        {heroSlides.map((s, i) => {
          // Before hydration only the first slide is requested.
          if (i > 0 && !mounted) return null;
          return (
            <picture key={`${s.base}-${i}`} className={`slideshow__slide${i === index ? ' is-active' : ''}`}>
              <source type="image/webp" srcSet={`${s.base}-1280.webp 1280w, ${s.base}-1920.webp 1920w`} sizes="100vw" />
              <img
                src={`${s.base}-1920.jpg`}
                alt={i === index ? s.alt : ''}
                width={1920}
                height={1080}
                style={{ objectPosition: s.position ?? 'center' }}
                loading={i === 0 ? 'eager' : 'lazy'}
                fetchPriority={i === 0 ? 'high' : 'low'}
                decoding="async"
              />
            </picture>
          );
        })}
      </div>
      <div className="slideshow__scrim" aria-hidden="true" />

      {count > 1 ? (
        <div
          className="slideshow__controls"
          role="group"
          aria-label="Campus photo slideshow"
          onMouseEnter={() => setHoverPaused(true)}
          onMouseLeave={() => setHoverPaused(false)}
          onFocus={() => setHoverPaused(true)}
          onBlur={() => setHoverPaused(false)}
        >
          <p className="slideshow__caption" aria-live={playing ? 'off' : 'polite'}>
            <span className="slideshow__count">
              {String(index + 1).padStart(2, '0')} / {String(count).padStart(2, '0')}
            </span>
            {heroSlides[index].caption}
          </p>
          <div className="slideshow__dots">
            {heroSlides.map((s, i) => (
              <button
                key={`${s.base}-${i}`}
                type="button"
                className={`slideshow__dot${i === index ? ' is-active' : ''}`}
                aria-label={`Show photo ${i + 1}: ${s.caption}`}
                aria-current={i === index ? 'true' : undefined}
                onClick={() => go(i)}
              />
            ))}
          </div>
          {!reducedMotion ? (
            <button
              type="button"
              className="slideshow__toggle"
              aria-pressed={userPaused}
              onClick={() => setUserPaused((p) => !p)}
            >
              {userPaused ? (
                <svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path d="M7 5v14l12-7Z" fill="currentColor" /></svg>
              ) : (
                <svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z" fill="currentColor" /></svg>
              )}
              <span className="visually-hidden">{userPaused ? 'Play slideshow' : 'Pause slideshow'}</span>
            </button>
          ) : null}
        </div>
      ) : (
        <p className="slideshow__caption slideshow__caption--static">{heroSlides[0]?.caption}</p>
      )}
    </div>
  );
}
