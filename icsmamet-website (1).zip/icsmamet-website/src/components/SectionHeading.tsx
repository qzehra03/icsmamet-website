import type { ReactNode } from 'react';

interface SectionHeadingProps {
  eyebrow?: string;
  title: ReactNode;
  intro?: ReactNode;
  id?: string;
  as?: 'h1' | 'h2' | 'h3';
  align?: 'start' | 'center';
  tone?: 'light' | 'dark';
}

export function SectionHeading({ eyebrow, title, intro, id, as: Tag = 'h2', align = 'start', tone = 'light' }: SectionHeadingProps) {
  return (
    <div className={`section-heading section-heading--${align} section-heading--${tone}`}>
      {eyebrow ? <p className="eyebrow">{eyebrow}</p> : null}
      <Tag id={id} className="section-heading__title">
        {title}
      </Tag>
      {intro ? <div className="section-heading__intro">{intro}</div> : null}
    </div>
  );
}
