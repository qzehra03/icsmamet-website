import type { ReactNode } from 'react';
import { Icon } from './Icon';

interface PendingNoticeProps {
  title: string;
  children?: ReactNode;
  compact?: boolean;
}

/** Neutral notice for information the organizers have not yet published. */
export function PendingNotice({ title, children, compact }: PendingNoticeProps) {
  return (
    <div className={`pending${compact ? ' pending--compact' : ''}`} role="note">
      <Icon name="clock" size={18} />
      <div>
        <p className="pending__title">{title}</p>
        {children ? <div className="pending__body">{children}</div> : null}
      </div>
    </div>
  );
}
