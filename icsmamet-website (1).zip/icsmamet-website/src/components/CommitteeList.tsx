import type { CommitteeGroup } from '../data/committees';

export function CommitteeLeadership({ groups }: { groups: CommitteeGroup[] }) {
  return (
    <div className="leadership-grid">
      {groups.map((g) => (
        <section key={g.id} className="leader-card" aria-labelledby={`${g.id}-h`}>
          <h3 id={`${g.id}-h`} className="leader-card__role">
            {g.title}
          </h3>
          {g.members.map((m) => (
            <div key={m.name}>
              <p className="leader-card__name">{m.name}</p>
              <p className="leader-card__detail">{[m.role, m.affiliation].filter(Boolean).join(', ')}</p>
            </div>
          ))}
        </section>
      ))}
    </div>
  );
}

export function CommitteeList({ group }: { group: CommitteeGroup }) {
  return (
    <section className="committee" id={group.id} aria-labelledby={`${group.id}-h`}>
      <h3 id={`${group.id}-h`} className="committee__title">
        {group.title}
        <span className="committee__count">{group.members.length}</span>
      </h3>
      <ol className="committee__members">
        {group.members.map((m) => (
          <li key={m.name}>
            <span className="committee__name">{m.name}</span>
            {m.role || m.affiliation ? (
              <span className="committee__affil">{[m.role, m.affiliation].filter(Boolean).join(', ')}</span>
            ) : null}
          </li>
        ))}
      </ol>
    </section>
  );
}
