import { Link } from 'react-router-dom';
import { conference } from '../data/conference';
import { daysUntil, nextDeadline } from '../data/deadlines';
import { tracks } from '../data/tracks';
import { useNow } from '../hooks/useNow';
import { RegisterAction, SubmitPaperAction } from './ConferenceActions';
import { formatDays } from './DeadlineTimeline';
import { HeroSlideshow } from './HeroSlideshow';
import { Icon } from './Icon';

/** Homepage hero: conference card over a full-bleed campus photo slideshow. */
export function Hero() {
  const now = useNow();
  const next = now ? nextDeadline(now) : undefined;

  return (
    <section className="hero" aria-labelledby="page-title">
      <HeroSlideshow />

      <div className="container hero__inner">
        <div className="hero-card">
          <div className="hero-card__main">
            <p className="hero__kicker">
              <span>International Conference</span>
              <span aria-hidden="true">·</span>
              <span>{conference.dates.display}</span>
            </p>
            <p className="hero__identity">
              <span className="hero__acronym">{conference.shortName}</span>
              <span className="hero__fullname">{conference.name}</span>
            </p>
            <h1 id="page-title" className="hero__title" tabIndex={-1}>
              {conference.tagline}
            </h1>
            <p className="hero__lead">{conference.strapline}</p>
            <div className="hero__actions">
              <SubmitPaperAction tone="dark" size="lg" />
              <RegisterAction tone="dark" size="lg" />
              <Link className="hero__explore" to="/about">
                Explore the conference <Icon name="arrowUpRight" size={16} />
              </Link>
            </div>
          </div>

          <dl className="hero-card__facts" aria-label="Conference at a glance">
            <div>
              <dt>Dates</dt>
              <dd>{conference.dates.display}</dd>
            </div>
            <div>
              <dt>Host</dt>
              <dd>
                {conference.host.short}
                <span className="hero__facts-sub">
                  {conference.host.locality}, {conference.host.city}
                </span>
              </dd>
            </div>
            <div>
              <dt>Tracks</dt>
              <dd>
                <ul className="hero-card__tracks">
                  {tracks.map((t) => (
                    <li key={t.id}>
                      <Link to={`/themes#${t.id}`}>{t.title}</Link>
                    </li>
                  ))}
                </ul>
              </dd>
            </div>
            <div aria-live="polite">
              <dt>Next milestone</dt>
              <dd>
                {next && now ? (
                  <>
                    {next.label}
                    <span className="hero__facts-sub">
                      {next.display} · {formatDays(daysUntil(next.date, now))}
                    </span>
                  </>
                ) : (
                  <Link to="/important-dates">See important dates</Link>
                )}
              </dd>
            </div>
          </dl>
        </div>
      </div>
    </section>
  );
}
