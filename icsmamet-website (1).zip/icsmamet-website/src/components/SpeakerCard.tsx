import { initials, type Speaker } from '../data/speakers';

interface SpeakerCardProps {
  speaker: Speaker;
  variant?: 'compact' | 'full';
  headingLevel?: 'h3' | 'h2';
}

export function SpeakerCard({ speaker, variant = 'full', headingLevel: H = 'h3' }: SpeakerCardProps) {
  const pending = !speaker.bio && !speaker.lectureTitle;
  return (
    <article className={`speaker-card speaker-card--${variant}`}>
      <div className="speaker-card__portrait">
        {speaker.photo ? (
          <img src={speaker.photo} alt={`Portrait of ${speaker.name}`} width={320} height={320} loading="lazy" decoding="async" />
        ) : (
          <span className="speaker-card__monogram" aria-hidden="true">
            {initials(speaker.name)}
          </span>
        )}
      </div>
      <div className="speaker-card__body">
        <p className="speaker-card__label">Invited speaker</p>
        <H className="speaker-card__name">{speaker.name}</H>
        {speaker.designation ? <p className="speaker-card__designation">{speaker.designation}</p> : null}
        <ul className="speaker-card__affiliations">
          {speaker.affiliations.map((a) => (
            <li key={a}>{a}</li>
          ))}
        </ul>
        {speaker.location && variant === 'full' ? <p className="speaker-card__location">{speaker.location}</p> : null}

        {variant === 'full' ? (
          <div className="speaker-card__details">
            {speaker.lectureTitle ? (
              <p className="speaker-card__lecture">
                <span>Lecture</span> {speaker.lectureTitle}
              </p>
            ) : null}
            {speaker.expertise?.length ? (
              <ul className="tag-list" aria-label="Research expertise">
                {speaker.expertise.map((e) => (
                  <li key={e}>{e}</li>
                ))}
              </ul>
            ) : null}
            {speaker.bio ? <p className="speaker-card__bio">{speaker.bio}</p> : null}
            {speaker.abstract ? <p className="speaker-card__abstract">{speaker.abstract}</p> : null}
            {pending ? (
              <p className="speaker-card__pending">Biography and lecture title to be announced.</p>
            ) : null}
          </div>
        ) : null}
      </div>
    </article>
  );
}
