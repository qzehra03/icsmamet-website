import { daysUntil, deadlines, nextDeadline, toLocalDate, type Deadline } from '../data/deadlines';
import { useNow } from '../hooks/useNow';

interface DeadlineTimelineProps {
  variant?: 'full' | 'compact';
  items?: Deadline[];
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function DateParts({ d }: { d: Deadline }) {
  const start = toLocalDate(d.date);
  const day = d.endDate ? `${start.getDate()}–${toLocalDate(d.endDate).getDate()}` : String(start.getDate());
  const month = MONTHS[start.getMonth()];
  return (
    <time className="timeline__date" dateTime={d.date}>
      <span className="timeline__day">{day}</span>
      <span className="timeline__month">
        {month} {start.getFullYear()}
      </span>
    </time>
  );
}

/** Deadline timeline in the order supplied by the organizers; the next upcoming item is highlighted after hydration. */
export function DeadlineTimeline({ variant = 'full', items = deadlines }: DeadlineTimelineProps) {
  const now = useNow();
  const next = now ? nextDeadline(now) : undefined;

  return (
    <ol className={`timeline timeline--${variant}`}>
      {items.map((d) => {
        const isNext = next?.id === d.id;
        return (
          <li key={d.id} className={`timeline__item timeline__item--${d.kind}${isNext ? ' is-next' : ''}`}>
            <span className="timeline__marker" aria-hidden="true" />
            <DateParts d={d} />
            <div className="timeline__text">
              <p className="timeline__label">{d.label}</p>
              <p className="timeline__full">{d.display}</p>
              {isNext && now ? (
                <p className="timeline__next">
                  Next milestone · {formatDays(daysUntil(d.date, now))}
                </p>
              ) : null}
            </div>
          </li>
        );
      })}
    </ol>
  );
}

export function formatDays(n: number): string {
  if (n <= 0) return 'today';
  if (n === 1) return 'in 1 day';
  return `in ${n} days`;
}
