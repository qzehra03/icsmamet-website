import { conference } from '../data/conference';
import { maps } from '../services/registrationService';
import { Icon } from './Icon';

export function MapEmbed() {
  return (
    <figure className="map">
      <div className="map__frame">
        <iframe
          src={maps.embedUrl}
          title={`Map showing the location of ${conference.host.short}, ${conference.host.locality}, ${conference.host.city}`}
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          allowFullScreen
        />
      </div>
      <figcaption className="map__caption">
        <span>
          <Icon name="pin" size={16} /> {conference.venueLine}
        </span>
        <span className="map__links">
          <a href={maps.openUrl} target="_blank" rel="noopener noreferrer">
            Open in Google Maps <Icon name="external" size={14} />
            <span className="visually-hidden">(opens in a new tab)</span>
          </a>
          <a href={maps.directionsUrl} target="_blank" rel="noopener noreferrer">
            Get directions <Icon name="external" size={14} />
            <span className="visually-hidden">(opens in a new tab)</span>
          </a>
        </span>
      </figcaption>
    </figure>
  );
}
