import { useId, useRef, useState, type FormEvent } from 'react';
import { integrations, submitForm } from '../services/registrationService';
import { Icon } from './Icon';

export interface FieldConfig {
  name: string;
  label: string;
  type?: 'text' | 'email' | 'tel' | 'date' | 'number' | 'textarea' | 'select';
  required?: boolean;
  options?: string[];
  autoComplete?: string;
  hint?: string;
  min?: string;
  max?: string;
  /** For date fields: must be on or after the value of this other field. */
  notBefore?: string;
  /** Grid span: "half" places two fields per row on wide screens. */
  span?: 'half' | 'full';
}

interface EnquiryFormProps {
  formName: string;
  subject: (values: Record<string, string>) => string;
  fields: FieldConfig[];
  submitLabel: string;
}

type Status =
  | { state: 'idle' }
  | { state: 'sending' }
  | { state: 'sent' }
  | { state: 'mailto'; href: string }
  | { state: 'error'; message: string; href?: string };

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validate(fields: FieldConfig[], values: Record<string, string>) {
  const errors: Record<string, string> = {};
  for (const f of fields) {
    const v = (values[f.name] ?? '').trim();
    if (f.required && !v) errors[f.name] = `Please enter ${f.label.toLowerCase()}.`;
    else if (v && f.type === 'email' && !EMAIL.test(v)) errors[f.name] = 'Please enter a valid email address.';
    else if (v && f.type === 'tel' && !/^[+()\d\s-]{6,20}$/.test(v)) errors[f.name] = 'Please enter a valid phone number.';
    else if (v && f.type === 'number' && f.min && Number(v) < Number(f.min)) errors[f.name] = `Must be at least ${f.min}.`;
    else if (v && f.notBefore && values[f.notBefore] && v < values[f.notBefore]) {
      const other = fields.find((x) => x.name === f.notBefore);
      errors[f.name] = `Must be on or after the ${other?.label.toLowerCase() ?? 'previous date'}.`;
    }
  }
  return errors;
}

/**
 * Accessible enquiry form with inline validation.
 * Sends to VITE_CONTACT_FORM_ENDPOINT when configured; otherwise prepares a
 * pre-filled email to the conveners (no data is stored by this website).
 */
export function EnquiryForm({ formName, subject, fields, submitLabel }: EnquiryFormProps) {
  const uid = useId();
  const formRef = useRef<HTMLFormElement>(null);
  const statusRef = useRef<HTMLDivElement>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<Status>({ state: 'idle' });

  const onSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    if (data.get('company_website')) return; // honeypot: silently ignore bots
    const values: Record<string, string> = {};
    for (const f of fields) values[f.name] = String(data.get(f.name) ?? '');

    const errs = validate(fields, values);
    setErrors(errs);
    const firstError = fields.find((f) => errs[f.name]);
    if (firstError) {
      formRef.current?.querySelector<HTMLElement>(`[name="${firstError.name}"]`)?.focus();
      return;
    }

    const labelled: Record<string, string> = {};
    for (const f of fields) labelled[f.label] = values[f.name];

    setStatus({ state: 'sending' });
    try {
      const result = await submitForm({ formName, subject: subject(values), fields: labelled });
      if (result.mode === 'sent') {
        setStatus({ state: 'sent' });
        formRef.current?.reset();
      } else {
        setStatus({ state: 'mailto', href: result.href });
        window.location.href = result.href;
      }
    } catch (err) {
      setStatus({
        state: 'error',
        message: err instanceof Error ? err.message : 'The message could not be sent.',
      });
    }
    requestAnimationFrame(() => statusRef.current?.focus());
  };

  const mailMode = !integrations.contactFormEndpoint;

  return (
    <form ref={formRef} className="form" noValidate onSubmit={onSubmit} aria-describedby={`${uid}-mode`}>
      <p id={`${uid}-mode`} className="form__mode">
        <Icon name="info" size={16} />
        {mailMode
          ? 'Submitting opens your email app with a message to both conveners, pre-filled with your details. Nothing is stored on this website.'
          : 'Your message is sent securely to the conference organizers.'}
      </p>
      <p className="form__required-note">
        Fields marked <span aria-hidden="true">*</span>
        <span className="visually-hidden">with an asterisk</span> are required.
      </p>

      <div className="form__grid">
        {fields.map((f) => {
          const id = `${uid}-${f.name}`;
          const err = errors[f.name];
          const describedBy = [f.hint ? `${id}-hint` : '', err ? `${id}-err` : ''].filter(Boolean).join(' ') || undefined;
          const common = {
            id,
            name: f.name,
            required: f.required,
            'aria-invalid': err ? true : undefined,
            'aria-describedby': describedBy,
          } as const;
          return (
            <div key={f.name} className={`field field--${f.span ?? 'full'}${err ? ' has-error' : ''}`}>
              <label htmlFor={id}>
                {f.label}
                {f.required ? <span className="field__req" aria-hidden="true"> *</span> : null}
              </label>
              {f.hint ? (
                <p id={`${id}-hint`} className="field__hint">
                  {f.hint}
                </p>
              ) : null}
              {f.type === 'textarea' ? (
                <textarea {...common} rows={5} />
              ) : f.type === 'select' ? (
                <select {...common} defaultValue="">
                  <option value="" disabled>
                    Select…
                  </option>
                  {f.options?.map((o) => (
                    <option key={o} value={o}>
                      {o}
                    </option>
                  ))}
                </select>
              ) : (
                <input {...common} type={f.type ?? 'text'} autoComplete={f.autoComplete} min={f.min} max={f.max} />
              )}
              {err ? (
                <p id={`${id}-err`} className="field__error">
                  {err}
                </p>
              ) : null}
            </div>
          );
        })}
        {/* Honeypot field, hidden from people and assistive tech */}
        <div className="hp" aria-hidden="true">
          <label htmlFor={`${uid}-hp`}>Company website</label>
          <input id={`${uid}-hp`} name="company_website" tabIndex={-1} autoComplete="off" />
        </div>
      </div>

      <div className="form__actions">
        <button type="submit" className="btn btn--primary" disabled={status.state === 'sending'}>
          {status.state === 'sending' ? 'Sending…' : submitLabel}
          <Icon name={mailMode ? 'mail' : 'arrowRight'} size={16} />
        </button>
      </div>

      <div ref={statusRef} tabIndex={-1} className="form__status" aria-live="polite">
        {status.state === 'sent' ? (
          <p className="notice notice--success">
            <Icon name="check" size={18} /> Thank you — your message has been sent to the organizers.
          </p>
        ) : null}
        {status.state === 'mailto' ? (
          <p className="notice">
            <Icon name="mail" size={18} />
            <span>
              Your email app should open with the message ready to send. If it didn’t,{' '}
              <a href={status.href}>open the pre-filled email</a> or write to the conveners directly using the
              addresses on this page.
            </span>
          </p>
        ) : null}
        {status.state === 'error' ? (
          <p className="notice notice--error">
            <Icon name="info" size={18} />
            <span>
              Sorry, the message could not be sent ({status.message}). Please email the conveners directly using the
              addresses on this page.
            </span>
          </p>
        ) : null}
      </div>
    </form>
  );
}
