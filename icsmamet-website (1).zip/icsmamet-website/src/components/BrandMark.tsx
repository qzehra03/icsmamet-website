/** Conference mark: a hexagonal lattice cell — materials structure as a monogram. */
export function BrandMark({ size = 40 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden="true" focusable="false" className="brand-mark">
      <rect width="48" height="48" rx="6" fill="var(--c-green-900)" />
      <g fill="none" stroke="var(--c-gold-300)" strokeWidth="1.6" strokeLinejoin="round">
        <path d="M24 9.5 36.5 16.75v14.5L24 38.5 11.5 31.25v-14.5Z" />
        <path d="M24 9.5v29M11.5 16.75 36.5 31.25M36.5 16.75 11.5 31.25" opacity="0.45" />
      </g>
      <g fill="var(--c-ivory)">
        <circle cx="24" cy="9.5" r="2.4" />
        <circle cx="36.5" cy="16.75" r="2.4" />
        <circle cx="36.5" cy="31.25" r="2.4" />
        <circle cx="24" cy="38.5" r="2.4" />
        <circle cx="11.5" cy="31.25" r="2.4" />
        <circle cx="11.5" cy="16.75" r="2.4" />
      </g>
      <circle cx="24" cy="24" r="3.2" fill="var(--c-gold-300)" />
    </svg>
  );
}
