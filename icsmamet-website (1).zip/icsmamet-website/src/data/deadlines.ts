/**
 * Important dates — reproduced exactly from the information document, in the
 * order it lists them.
 *
 * NOTE FOR ORGANIZERS: the document gives "15 March 2026" for Registration Open,
 * which precedes the Call for Papers opening (1 January 2027) and is already in
 * the past. It is published as supplied; correct `date` here if it should read 2027.
 */

export type DeadlineKind = 'milestone' | 'deadline' | 'event';

export interface Deadline {
  id: string;
  label: string;
  /** ISO date (start date for ranges). */
  date: string;
  endDate?: string;
  display: string;
  kind: DeadlineKind;
}

export const deadlines: Deadline[] = [
  { id: 'cfp-open', label: 'Call for papers opens', date: '2027-01-01', display: '1 January 2027', kind: 'milestone' },
  { id: 'registration-open', label: 'Registration opens', date: '2026-03-15', display: '15 March 2026', kind: 'milestone' },
  { id: 'early-bird', label: 'Early-bird registration ends', date: '2027-04-15', display: '15 April 2027', kind: 'deadline' },
  { id: 'final-paper', label: 'Final paper submission', date: '2027-05-01', display: '1 May 2027', kind: 'deadline' },
  { id: 'late-registration', label: 'Late registration ends', date: '2027-06-15', display: '15 June 2027', kind: 'deadline' },
  {
    id: 'conference',
    label: 'Conference days',
    date: '2027-07-21',
    endDate: '2027-07-23',
    display: '21–23 July 2027',
    kind: 'event',
  },
];

/** Time zone for all deadlines, once confirmed by the organizers (null = not yet announced). */
export const deadlineTimeZone: string | null = null;

export function getDeadline(id: string): Deadline {
  const d = deadlines.find((x) => x.id === id);
  if (!d) throw new Error(`Unknown deadline: ${id}`);
  return d;
}

/** Parse an ISO date as a local calendar day (avoids UTC off-by-one). */
export function toLocalDate(iso: string): Date {
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(y, m - 1, d);
}

/** The next deadline whose (end) date is today or later. */
export function nextDeadline(now: Date = new Date()): Deadline | undefined {
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  return [...deadlines]
    .sort((a, b) => a.date.localeCompare(b.date))
    .find((d) => toLocalDate(d.endDate ?? d.date) >= today);
}

export function daysUntil(iso: string, now: Date = new Date()): number {
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  return Math.round((toLocalDate(iso).getTime() - today.getTime()) / 86_400_000);
}
