/**
 * Conference committees, as listed in the information document.
 * Names and affiliations are reproduced as supplied (spacing normalised only).
 */

export interface Member {
  name: string;
  role?: string;
  affiliation?: string;
}

export interface CommitteeGroup {
  id: string;
  title: string;
  /** "leadership" groups render as prominent cards; "list" groups as compact lists. */
  layout: 'leadership' | 'list';
  members: Member[];
}

export const committees: CommitteeGroup[] = [
  {
    id: 'chief-patron',
    title: 'Chief Patron',
    layout: 'leadership',
    members: [{ name: 'Sri. D. Suresh Babu', role: 'President', affiliation: 'Vignana Jyothi' }],
  },
  {
    id: 'co-patron',
    title: 'Co-Patron',
    layout: 'leadership',
    members: [
      { name: 'Sri. Kode Durga Prasad, IPS (Retd.)', role: 'General Secretary', affiliation: 'Vignana Jyothi' },
    ],
  },
  {
    id: 'chairman',
    title: 'Chairman',
    layout: 'leadership',
    members: [{ name: 'Dr. B. Chennakesava Rao', role: 'Principal', affiliation: 'VNRVJIET' }],
  },
  {
    id: 'chief-advisor',
    title: 'Chief Advisor',
    layout: 'leadership',
    members: [{ name: 'Dr. S. Rajendra Prasad', role: 'Dean Administration' }],
  },
  {
    id: 'conveners',
    title: 'Conveners',
    layout: 'list',
    members: [
      { name: 'Dr. V.V.D. Sahithi', affiliation: 'VNR VJIET, Hyderabad' },
      { name: 'Dr. N. Srilatha', affiliation: 'VNR VJIET, Hyderabad' },
    ],
  },
  {
    id: 'co-conveners',
    title: 'Co-Conveners',
    layout: 'list',
    members: [{ name: 'Dr. K. Ajay Kumar' }, { name: 'Dr. N. Shiva Kumar' }],
  },
  {
    id: 'organizing',
    title: 'Organizing Committee',
    layout: 'list',
    members: [{ name: 'Dr. K. Jaya Prakash' }, { name: 'Dr. Rajeswari' }, { name: 'Mr. S. Naga Sai Hari' }],
  },
  {
    id: 'proceedings-editors',
    title: 'Proceedings Editors',
    layout: 'list',
    members: [
      { name: 'Dr. V.V.D. Sahithi', affiliation: 'VNR VJIET, Hyderabad' },
      { name: 'Dr. N. Srilatha', affiliation: 'VNR VJIET, Hyderabad' },
      { name: 'Dr. Prince Jeya Lal Lazar', affiliation: 'Rajalakshmi Institute of Technology, Chennai' },
    ],
  },
  {
    id: 'advisory',
    title: 'Advisory Committee',
    layout: 'list',
    members: [
      {
        name: 'Dr. Vineet S. Sikarwar',
        role: 'Scientist',
        affiliation:
          'Institute of Plasma Physics of the Czech Academy of Sciences; University of Chemistry and Technology in Prague (UCT Prague)',
      },
      { name: 'Dr. Vishnu Budama', role: 'CEO', affiliation: 'Pune Hydrogen Valley' },
      { name: 'Prof. Ravi Shankar', role: 'HOD / ME', affiliation: 'IIT Hyderabad' },
      { name: 'Dr. P. Pavan Kumar', affiliation: 'BITS Hyderabad' },
      { name: 'Dr. Prince Jeya Lal Lazar', affiliation: 'Rajalakshmi Institute of Technology, Chennai' },
    ],
  },
];
