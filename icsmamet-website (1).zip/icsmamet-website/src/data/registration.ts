/**
 * Registration fees — reproduced exactly from the information document.
 * The document supplies a single "Regular" rate per category. No early-bird
 * rates, tax treatment, payment instructions or cancellation policy have been
 * supplied; add them here once confirmed and the Registration page will show them.
 */

export interface FeeRow {
  category: string;
  regular: string;
}

export interface FeeGroup {
  id: 'indian' | 'overseas';
  delegateType: string;
  currency: 'INR' | 'USD';
  rows: FeeRow[];
}

export const feeGroups: FeeGroup[] = [
  {
    id: 'indian',
    delegateType: 'Indian Delegates',
    currency: 'INR',
    rows: [
      { category: 'Students (BTech/MTech)', regular: '₹5,000' },
      {
        category: 'Academic delegates: Faculty, Ph.D. scholars, post-doctoral fellows, public sector R&Ds',
        regular: '₹7,000',
      },
      { category: 'Non-academic / Industry delegates', regular: '₹10,000' },
    ],
  },
  {
    id: 'overseas',
    delegateType: 'Overseas Delegates',
    currency: 'USD',
    rows: [
      { category: 'Research scholars / students', regular: 'US$250' },
      { category: 'Academic delegates: Faculty, post-doctoral fellows, public sector R&Ds', regular: 'US$350' },
      { category: 'Non-academic / Industry delegates', regular: 'US$500' },
    ],
  },
];

/**
 * Policies that the organizers still need to confirm. `null` means "not yet
 * published" — the page then shows a neutral pending notice rather than guessing.
 */
export const registrationPolicies: { id: string; title: string; text: string | null }[] = [
  { id: 'early-bird', title: 'Early-bird rates', text: null },
  { id: 'payment', title: 'Payment instructions', text: null },
  { id: 'author', title: 'Author registration policy', text: null },
  { id: 'taxes', title: 'Taxes and additional charges', text: null },
  { id: 'cancellation', title: 'Cancellation and refund policy', text: null },
];
