/**
 * Core conference identity and host-institution content.
 * Source of truth: "International Conference on Sustainable Materials" information document.
 * Edit text here — pages read from this file and never hard-code conference facts.
 */

export const conference = {
  acronym: 'ICSMAMET',
  edition: '2027',
  shortName: 'ICSMAMET 2027',
  name: 'International Conference on Sustainable Materials, Advanced Manufacturing and Emerging Technologies',
  tagline: 'Engineering a more sustainable future.',
  strapline:
    'Advancing sustainable materials, next-generation manufacturing and emerging technologies through interdisciplinary research and innovation.',
  dates: {
    start: '2027-07-21',
    end: '2027-07-23',
    display: '21–23 July 2027',
  },
  host: {
    short: 'VNR VJIET',
    name: 'Vallurupalli Nageswara Rao Vignana Jyothi Institute of Engineering & Technology',
    city: 'Hyderabad',
    locality: 'Bachupally',
    region: 'Telangana',
    country: 'India',
  },
  /** Venue as supplied. A full postal address has not been provided yet. */
  venueLine: 'VNR VJIET, Bachupally, Hyderabad, Telangana, India',
} as const;

/** Conference purpose — text from the "Themes" section of the information document. */
export const overview = {
  context:
    'Manufacturing and materials technologies play a vital role in economic growth, technological advancement, and sustainable development. The rapid development of advanced materials, smart manufacturing, additive manufacturing, artificial intelligence, and digital technologies is creating new opportunities for efficient, sustainable, and high-performance engineering solutions.',
  aim:
    'The International Conference on Sustainable Materials, Advanced Manufacturing and Emerging Technologies (ICSMAMET) aims to bring together researchers, academicians, industry professionals, and practitioners to share recent developments, innovations, and emerging trends in sustainable materials, advanced manufacturing processes, and intelligent technologies. The conference will provide a platform for exchanging knowledge, discussing current challenges, and exploring future directions in manufacturing and materials engineering.',
  format:
    'The conference will feature plenary and invited lectures, technical sessions, and contributed research papers covering theoretical, experimental, computational, and industrial developments.',
  formatItems: ['Plenary lectures', 'Invited lectures', 'Technical sessions', 'Contributed research papers'],
  coverage: ['Theoretical', 'Experimental', 'Computational', 'Industrial'],
  audience: ['Researchers', 'Academicians', 'Industry professionals', 'Practitioners'],
  objectives: [
    'Share recent developments, innovations and emerging trends in sustainable materials, advanced manufacturing processes and intelligent technologies.',
    'Provide a platform for exchanging knowledge between researchers, academicians, industry professionals and practitioners.',
    'Discuss current challenges in manufacturing and materials engineering.',
    'Explore future directions in manufacturing and materials engineering.',
  ],
} as const;

/** Homepage "research imperative" copy, from the website specification. */
export const imperative = {
  eyebrow: 'The research imperative',
  title: 'From materials discovery to intelligent manufacturing',
  body:
    'Bringing materials researchers, manufacturing engineers, computational scientists and industry practitioners together to address resource efficiency, performance, automation and sustainable production.',
  pillars: [
    {
      title: 'Research exchange',
      body: 'Share experimental, theoretical and computational advances.',
    },
    {
      title: 'Interdisciplinary collaboration',
      body: 'Connect academia, industry and emerging technology communities.',
    },
  ],
} as const;

/** About VNR VJIET — from the information document. */
export const institution = {
  heading: 'About VNR VJIET',
  paragraphs: [
    'In 1995, Vignana Jyothi established the Vallurupalli Nageswara Rao Vignana Jyothi Institute of Engineering & Technology (VNR VJIET) at Bachupally, Hyderabad. The institute is affiliated to Jawaharlal Nehru Technological University, Hyderabad (JNTUH), approved by AICTE, New Delhi, and recognized by the Government of Telangana. In 2012, VNR VJIET was granted Autonomous Status by the University Grants Commission (UGC).',
    'Today, VNRVJIET proudly holds NAAC A++ accreditation with a CGPA of 3.68/4.0, ranks in the 151–200 band in NIRF 2025 (Engineering), and is recognized among the best engineering institutes in Telangana.',
    'VNRVJIET distinguishes itself through its research orientation, world-class infrastructure, and innovative pedagogy led by experienced faculty for the holistic development of students.',
    "With a distinct perspective shaped by the vision of Vignana Jyothi Society, VNR VJIET has, for over three decades, earned its place among India's top-ranking institutions. It continues to produce a value-sensitive workforce and leaders of tomorrow, joining the league of exclusive and preferred institutions in technical education.",
  ],
  programs: [
    { level: 'Undergraduate', detail: '17 B.Tech specializations across core and emerging engineering disciplines' },
    { level: 'Postgraduate', detail: 'M.Tech programs in multiple streams and MCA' },
    { level: 'Doctoral Research', detail: 'Ph.D. programs supported by five JNTUH recognized research centres' },
  ],
  facts: [
    { value: '1995', label: 'Established by Vignana Jyothi' },
    { value: 'A++', label: 'NAAC accreditation · CGPA 3.68/4.0' },
    { value: '151–200', label: 'NIRF 2025 band (Engineering)' },
    { value: '17', label: 'B.Tech specializations' },
    { value: '5', label: 'JNTUH recognized research centres' },
  ],
  recognitions: [
    'Affiliated to JNTUH',
    'Approved by AICTE, New Delhi',
    'Recognized by the Government of Telangana',
    'Autonomous Status (UGC, 2012)',
  ],
  image: {
    base: '/images/campus/vnrvjiet-campus',
    alt: 'Aerial view of the VNR VJIET campus buildings surrounded by trees at Bachupally, Hyderabad',
    width: 1378,
    height: 603,
  },
} as const;

export const accommodation = {
  summary:
    'Accommodation facilities will be available for participants at the VNR VJIET hostels and guest house on a paid basis, subject to availability and prior request.',
  options: [
    { name: 'VNR VJIET hostels', basis: 'Paid basis · subject to availability and prior request' },
    { name: 'VNR VJIET guest house', basis: 'Paid basis · subject to availability and prior request' },
  ],
} as const;
