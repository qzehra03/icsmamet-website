/**
 * Downloadable documents. None have been supplied yet.
 * When a PDF is approved, place it in /public/documents/ and set `href`.
 * Items without an `href` render as "Not yet published" (never as a dead link).
 */

export interface ConferenceDocument {
  id: string;
  title: string;
  description: string;
  href?: string;
}

export const documents: ConferenceDocument[] = [
  {
    id: 'call-for-papers',
    title: 'Call for Papers',
    description: 'Scope, tracks and submission timeline.',
    // href: '/documents/call-for-papers.pdf',
  },
  {
    id: 'author-guidelines',
    title: 'Author Guidelines & Paper Template',
    description: 'Formatting, length and submission requirements.',
    // href: '/documents/author-guidelines.pdf',
  },
];
