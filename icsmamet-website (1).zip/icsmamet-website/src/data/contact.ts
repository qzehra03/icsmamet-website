/**
 * Conference contacts — from the information document.
 */

export interface Contact {
  name: string;
  role: string;
  email: string;
  /** Display form */
  phone: string;
  /** E.164 form for tel: links (Indian mobile numbers, +91). */
  phoneE164: string;
}

export const contacts: Contact[] = [
  {
    name: 'Dr. V.V.D. Sahithi',
    role: 'Convener',
    email: 'sahithi_vvd@vnrvjiet.in',
    phone: '+91 99088 66756',
    phoneE164: '+919908866756',
  },
  {
    name: 'Dr. N. Srilatha',
    role: 'Convener',
    email: 'srilatha_n@vnrvjiet.in',
    phone: '+91 94943 84578',
    phoneE164: '+919494384578',
  },
];

export const contactEmails = contacts.map((c) => c.email);
