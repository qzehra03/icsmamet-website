/**
 * Invited speakers, as listed in the information document.
 * Photographs, biographies, expertise and lecture titles have NOT been supplied.
 * Add them here once approved — the cards render them automatically.
 */

export interface Speaker {
  id: string;
  name: string;
  designation?: string;
  affiliations: string[];
  location?: string;
  /** Path under /public, e.g. '/images/speakers/sikarwar.webp' (approved photograph only). */
  photo?: string;
  bio?: string;
  expertise?: string[];
  lectureTitle?: string;
  abstract?: string;
}

export const speakers: Speaker[] = [
  {
    id: 'vineet-sikarwar',
    name: 'Dr. Vineet S. Sikarwar',
    designation: 'Scientist',
    affiliations: [
      'Institute of Plasma Physics of the Czech Academy of Sciences',
      'University of Chemistry and Technology in Prague (UCT Prague)',
    ],
    location: 'Prague, Czech Republic',
  },
  {
    id: 'vishnu-budama',
    name: 'Dr. Vishnu Budama',
    designation: 'CEO',
    affiliations: ['Pune Hydrogen Valley'],
  },
  {
    id: 'ravi-shankar',
    name: 'Prof. Ravi Shankar',
    designation: 'HOD / ME',
    affiliations: ['IIT Hyderabad'],
  },
  {
    id: 'pavan-kumar',
    name: 'Dr. P. Pavan Kumar',
    affiliations: ['BITS Hyderabad'],
  },
];

/** Initials for the monogram used until an approved photograph is supplied. */
export function initials(name: string): string {
  const parts = name
    .replace(/^(Dr|Prof|Mr|Ms|Mrs|Sri)\.?\s+/i, '')
    .split(/\s+/)
    .filter((p) => p.length > 1 && !p.endsWith('.'));
  const first = parts[0]?.[0] ?? '';
  const last = parts.length > 1 ? parts[parts.length - 1][0] : '';
  return (first + last).toUpperCase();
}
