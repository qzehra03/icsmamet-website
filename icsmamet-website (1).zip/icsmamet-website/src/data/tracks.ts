/**
 * Technical tracks. Topic lists are reproduced exactly from the information document.
 * Track titles follow the website specification's three conference pillars
 * (Sustainable Materials · Advanced Manufacturing · Emerging Technologies).
 */

export type TrackMotif = 'lattice' | 'layers' | 'network';

export interface Track {
  id: string;
  number: 1 | 2 | 3;
  title: string;
  focus: string;
  motif: TrackMotif;
  topics: string[];
}

export const tracks: Track[] = [
  {
    id: 'track-1',
    number: 1,
    title: 'Sustainable Materials',
    focus: 'Materials design, functional materials, characterization and testing',
    motif: 'lattice',
    topics: [
      'Sustainable materials',
      'Quantum materials',
      '3D Printing materials',
      'Shape memory alloys',
      'Composite and Polymer Manufacturing',
      'Composites, Intermetallic',
      'Functionally Graded Materials',
      'Phase change materials',
      'Energy storage materials',
      'Nano materials',
      'Future generation materials',
      'Material Characterization',
      'Material Testing',
    ],
  },
  {
    id: 'track-2',
    number: 2,
    title: 'Advanced Manufacturing',
    focus: 'Additive, green, smart and non-traditional manufacturing processes',
    motif: 'layers',
    topics: [
      'Additive Manufacturing',
      'Sustainable & Green Manufacturing',
      'Digital Twins and Intelligent Process Monitoring',
      'Advanced Machining & Forming',
      'Smart Manufacturing & Industry 5.0',
      'Robotics, Automation & Mechatronics',
      'Micro- and Nano-Manufacturing',
      'Non-Traditional Manufacturing',
    ],
  },
  {
    id: 'track-3',
    number: 3,
    title: 'Emerging Technologies',
    focus: 'Modelling, simulation, optimization and machine learning for manufacturing',
    motif: 'network',
    topics: [
      'Numerical Modelling and Simulation',
      'Optimization Techniques',
      'Multi-Objective Optimization',
      'AI-Based Process Parameter Optimization',
      'Machine Learning for Manufacturing Performance Prediction',
    ],
  },
];
