/**
 * Homepage background slideshow — VNR VJIET campus photographs.
 *
 * To add a photo: put optimized files in /public/images/campus/ as
 *   <name>-1280.webp, <name>-1920.webp and <name>-1920.jpg
 * (see README → "Hero slideshow photos"), then add an entry below.
 * Slides appear in this order; the first one loads immediately.
 */

export interface HeroSlide {
  /** Path prefix under /public, without the size suffix. */
  base: string;
  /** Describe what the photo shows (read by screen readers). */
  alt: string;
  /** Short caption shown in the slideshow controls. */
  caption: string;
  /** Focal point for cropping, CSS object-position (default 'center'). */
  position?: string;
}

export const heroSlides: HeroSlide[] = [
  {
    base: '/images/campus/hero-silicon-bhavan',
    alt: 'Silicon Bhavan, a multi-storey academic block at VNR VJIET, with its inauguration plaque and tree-lined road',
    caption: 'Silicon Bhavan, VNR VJIET',
  },
  {
    base: '/images/campus/hero-main-building',
    alt: 'Entrance of the VNR Vignana Jyothi Institute of Engineering and Technology building with students walking in front',
    caption: 'VNR VJIET main building',
  },
  {
    base: '/images/campus/hero-auditorium',
    alt: 'Speakers on stage addressing a full auditorium of students at VNR VJIET',
    caption: 'Auditorium',
  },
  {
    base: '/images/campus/hero-amphitheatre',
    alt: 'Students seated on the steps of the campus amphitheatre while a speaker addresses them',
    caption: 'Amphitheatre',
  },
  {
    base: '/images/campus/hero-computer-lab',
    alt: 'Students working at computers in a VNR VJIET computer laboratory',
    caption: 'Computer laboratory',
  },
  {
    base: '/images/campus/hero-campus-aerial',
    alt: 'Aerial view of the VNR VJIET campus buildings surrounded by trees at Bachupally, Hyderabad',
    caption: 'VNR VJIET campus, Bachupally',
    position: 'center 40%',
  },
];

/** Seconds each slide stays on screen. */
export const SLIDE_SECONDS = 6;
