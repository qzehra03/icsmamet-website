import type { RouteObject } from 'react-router-dom';
import About from '../pages/About';
import Accommodation from '../pages/Accommodation';
import Committees from '../pages/Committees';
import Contact from '../pages/Contact';
import Home from '../pages/Home';
import ImportantDates from '../pages/ImportantDates';
import NotFound from '../pages/NotFound';
import Registration from '../pages/Registration';
import Speakers from '../pages/Speakers';
import Themes from '../pages/Themes';
import { Layout } from './Layout';

/**
 * All pages are bundled eagerly: the whole site is small, and every route is
 * prerendered to static HTML at build time, so hydration stays synchronous.
 */
export const routes: RouteObject[] = [
  {
    element: <Layout />,
    children: [
      { index: true, element: <Home /> },
      { path: 'about', element: <About /> },
      { path: 'themes', element: <Themes /> },
      { path: 'speakers', element: <Speakers /> },
      { path: 'committees', element: <Committees /> },
      { path: 'registration', element: <Registration /> },
      { path: 'accommodation', element: <Accommodation /> },
      { path: 'important-dates', element: <ImportantDates /> },
      { path: 'contact', element: <Contact /> },
      { path: '*', element: <NotFound /> },
    ],
  },
];
