import { useEffect, useRef } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { Footer } from '../components/Footer';
import { Header } from '../components/Header';

/**
 * Shared page shell. On client-side navigation it scrolls to the requested
 * anchor (or the top) and moves focus to the new page's <h1> so keyboard and
 * screen-reader users land at the start of the new content.
 */
export function Layout() {
  const { pathname, hash } = useLocation();
  const first = useRef(true);

  useEffect(() => {
    const isFirst = first.current;
    first.current = false;

    if (hash) {
      const id = decodeURIComponent(hash.slice(1));
      const target = id === 'top' ? document.body : document.getElementById(id);
      if (target) {
        // Wait a frame so the new route has painted.
        requestAnimationFrame(() => {
          target.scrollIntoView({ block: 'start' });
          if (id !== 'top' && !isFirst) {
            if (!target.hasAttribute('tabindex')) target.setAttribute('tabindex', '-1');
            target.focus({ preventScroll: true });
          }
        });
        return;
      }
    }
    if (isFirst) return;
    window.scrollTo(0, 0);
    document.getElementById('page-title')?.focus({ preventScroll: true });
  }, [pathname, hash]);

  return (
    <div className="site" id="top">
      <a className="skip-link" href="#main">
        Skip to main content
      </a>
      <Header />
      <main id="main" tabIndex={-1}>
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}
