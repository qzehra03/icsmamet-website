import { conference } from '../data/conference';

export interface PageMeta {
  path: string;
  /** Label used in navigation. */
  label: string;
  /** Section number shown on inner-page headers (spec numbering 01–08). */
  number?: string;
  title: string;
  description: string;
  inNav: boolean;
}

const suffix = ` | ${conference.shortName}`;

export const pages: PageMeta[] = [
  {
    path: '/',
    label: 'Home',
    title: `${conference.shortName} — ${conference.name}`,
    description: `${conference.name} (${conference.shortName}), ${conference.dates.display}, hosted by VNR VJIET, Hyderabad, India. Sustainable materials, advanced manufacturing and emerging technologies.`,
    inNav: false,
  },
  {
    path: '/about',
    label: 'About',
    number: '01',
    title: `About the Conference${suffix}`,
    description: `Overview, objectives and format of ${conference.shortName}, and the host institution VNR VJIET, Bachupally, Hyderabad.`,
    inNav: true,
  },
  {
    path: '/themes',
    label: 'Themes',
    number: '02',
    title: `Themes & Call for Papers${suffix}`,
    description: `The three technical tracks of ${conference.shortName} — sustainable materials, advanced manufacturing and emerging technologies — with full topic lists and call for papers information.`,
    inNav: true,
  },
  {
    path: '/speakers',
    label: 'Invited Speakers',
    number: '03',
    title: `Invited Speakers${suffix}`,
    description: `Invited speakers at ${conference.shortName} from the Czech Academy of Sciences, UCT Prague, Pune Hydrogen Valley, IIT Hyderabad and BITS Hyderabad.`,
    inNav: true,
  },
  {
    path: '/committees',
    label: 'Committees',
    number: '04',
    title: `Committees${suffix}`,
    description: `Patrons, chairman, conveners, organizing committee, proceedings editors and advisory committee of ${conference.shortName}.`,
    inNav: true,
  },
  {
    path: '/registration',
    label: 'Registration',
    number: '05',
    title: `Registration & Fees${suffix}`,
    description: `Registration fees for Indian and overseas delegates at ${conference.shortName}, with registration process and key deadlines.`,
    inNav: true,
  },
  {
    path: '/accommodation',
    label: 'Accommodation',
    number: '06',
    title: `Accommodation${suffix}`,
    description: `Paid hostel and guest-house accommodation at VNR VJIET for ${conference.shortName} participants, subject to availability and prior request.`,
    inNav: true,
  },
  {
    path: '/important-dates',
    label: 'Important Dates',
    number: '07',
    title: `Important Dates${suffix}`,
    description: `Call for papers, registration and submission deadlines for ${conference.shortName}. Conference days: ${conference.dates.display}.`,
    inNav: true,
  },
  {
    path: '/contact',
    label: 'Contact',
    number: '08',
    title: `Contact${suffix}`,
    description: `Contact the ${conference.shortName} conveners at VNR VJIET, Hyderabad — email, phone, venue map and enquiry form.`,
    inNav: true,
  },
];

export const notFoundMeta: PageMeta = {
  path: '/404',
  label: 'Page not found',
  title: `Page not found${suffix}`,
  description: `The page you were looking for could not be found on the ${conference.shortName} website.`,
  inNav: false,
};

export const navPages = pages.filter((p) => p.inNav);

export function metaFor(path: string): PageMeta {
  const clean = path.replace(/\/+$/, '') || '/';
  return pages.find((p) => p.path === clean) ?? notFoundMeta;
}
