import { Link } from 'react-router-dom';
import { metaFor } from '../app/siteMap';
import { IntegrationStatus } from '../components/ConferenceActions';
import { DeadlineTimeline } from '../components/DeadlineTimeline';
import { Icon } from '../components/Icon';
import { PageHero } from '../components/PageHero';
import { PendingNotice } from '../components/PendingNotice';
import { RegistrationTable } from '../components/RegistrationTable';
import { SectionHeading } from '../components/SectionHeading';
import { contacts } from '../data/contact';
import { deadlines } from '../data/deadlines';
import { feeGroups, registrationPolicies } from '../data/registration';
import { usePageMeta } from '../hooks/usePageMeta';

const registrationDates = deadlines.filter((d) =>
  ['registration-open', 'early-bird', 'final-paper', 'late-registration', 'conference'].includes(d.id),
);

export default function Registration() {
  const meta = metaFor('/registration');
  usePageMeta(meta);
  const published = registrationPolicies.filter((p) => p.text);
  const pending = registrationPolicies.filter((p) => !p.text);

  return (
    <>
      <PageHero
        meta={meta}
        title="Registration"
        lead={<p>Registration fees for Indian and overseas delegates, the registration process and key deadlines.</p>}
        aside={
          <dl className="hero-facts">
            {feeGroups.map((g) => (
              <div key={g.id}>
                <dt>{g.delegateType}</dt>
                <dd>
                  {g.rows[0].regular} – {g.rows[g.rows.length - 1].regular}
                </dd>
              </div>
            ))}
          </dl>
        }
      />

      <section className="section" aria-labelledby="fees-title">
        <div className="container">
          <SectionHeading
            eyebrow="Fees"
            title="Registration fees"
            id="fees-title"
            intro={<p>Fees are listed by delegate type and category. Amounts shown are the regular rates.</p>}
          />
          <RegistrationTable groups={feeGroups} />
        </div>
      </section>

      <section className="section section--ivory" aria-labelledby="process-title">
        <div className="container cfp-grid">
          <div className="cfp-grid__main">
            <SectionHeading eyebrow="Process" title="How to register" id="process-title" />
            <IntegrationStatus kind="registration" />
            <ol className="steps">
              <li>
                <span className="steps__title">Identify your category</span>
                <span>Find your delegate type and category in the fee table above.</span>
              </li>
              <li>
                <span className="steps__title">Complete the registration form</span>
                <span>Use the official registration link, which will be published on this page.</span>
              </li>
              <li>
                <span className="steps__title">Pay the registration fee</span>
                <span>
                  Follow the payment instructions provided with the registration form. This website does not collect
                  payment details.
                </span>
              </li>
              <li>
                <span className="steps__title">Keep your confirmation</span>
                <span>
                  Retain your registration and payment confirmation. For questions, contact{' '}
                  {contacts.map((c, i) => (
                    <span key={c.email}>
                      {i > 0 ? ' or ' : ''}
                      <a href={`mailto:${c.email}`}>{c.name}</a>
                    </span>
                  ))}
                  .
                </span>
              </li>
            </ol>
          </div>

          <aside className="cfp-grid__side" aria-labelledby="reg-dates-title">
            <h3 id="reg-dates-title" className="sub-heading">
              Registration dates
            </h3>
            <DeadlineTimeline variant="compact" items={registrationDates} />
            <Link className="link-arrow" to="/important-dates">
              All important dates <Icon name="arrowRight" size={16} />
            </Link>
          </aside>
        </div>
      </section>

      <section className="section" aria-labelledby="policies-title">
        <div className="container">
          <SectionHeading eyebrow="Policies" title="Registration policies" id="policies-title" />
          {published.length ? (
            <div className="policy-grid">
              {published.map((p) => (
                <div key={p.id} className="policy">
                  <h3>{p.title}</h3>
                  <p>{p.text}</p>
                </div>
              ))}
            </div>
          ) : null}
          {pending.length ? (
            <PendingNotice title="To be announced by the organizers">
              <p>The following details will be published on this page once confirmed:</p>
              <ul className="pending__list">
                {pending.map((p) => (
                  <li key={p.id}>{p.title}</li>
                ))}
              </ul>
            </PendingNotice>
          ) : null}
        </div>
      </section>
    </>
  );
}
