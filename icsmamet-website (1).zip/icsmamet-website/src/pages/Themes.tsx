import { Link } from 'react-router-dom';
import { metaFor } from '../app/siteMap';
import { IntegrationStatus } from '../components/ConferenceActions';
import { Icon } from '../components/Icon';
import { PageHero } from '../components/PageHero';
import { PendingNotice } from '../components/PendingNotice';
import { SectionHeading } from '../components/SectionHeading';
import { TrackCard } from '../components/TrackCard';
import { overview } from '../data/conference';
import { getDeadline } from '../data/deadlines';
import { documents } from '../data/documents';
import { tracks } from '../data/tracks';
import { usePageMeta } from '../hooks/usePageMeta';

export default function Themes() {
  const meta = metaFor('/themes');
  usePageMeta(meta);
  const cfp = getDeadline('cfp-open');
  const finalPaper = getDeadline('final-paper');
  const totalTopics = tracks.reduce((n, t) => n + t.topics.length, 0);

  return (
    <>
      <PageHero
        meta={meta}
        title="Conference themes"
        lead={<p>{overview.aim}</p>}
        aside={
          <dl className="hero-facts">
            <div>
              <dt>Tracks</dt>
              <dd>{tracks.length}</dd>
            </div>
            <div>
              <dt>Topics</dt>
              <dd>{totalTopics}</dd>
            </div>
            <div>
              <dt>Call for papers opens</dt>
              <dd>{cfp.display}</dd>
            </div>
          </dl>
        }
      />

      <section className="section" aria-labelledby="tracks-title">
        <div className="container">
          <SectionHeading
            eyebrow="Technical tracks"
            title="Research tracks and topics"
            id="tracks-title"
            intro={<p>{overview.format}</p>}
          />
          <nav className="jump-links" aria-label="Jump to track">
            {tracks.map((t) => (
              <a key={t.id} href={`#${t.id}`}>
                <span>Track {String(t.number).padStart(2, '0')}</span> {t.title}
              </a>
            ))}
          </nav>
          <div className="track-grid track-grid--full">
            {tracks.map((t) => (
              <TrackCard key={t.id} track={t} variant="full" />
            ))}
          </div>
        </div>
      </section>

      <section className="section section--ivory" aria-labelledby="audience-title">
        <div className="container split">
          <SectionHeading eyebrow="Audience" title="Intended audience and interdisciplinary scope" id="audience-title" />
          <div className="prose">
            <p>
              ICSMAMET brings together {overview.audience.slice(0, -1).join(', ').toLowerCase()} and{' '}
              {overview.audience[overview.audience.length - 1].toLowerCase()} working across materials, manufacturing and
              intelligent technologies. Contributions may cover {overview.coverage.slice(0, -1).join(', ').toLowerCase()}{' '}
              and {overview.coverage[overview.coverage.length - 1].toLowerCase()} developments.
            </p>
            <ul className="chip-list">
              {overview.audience.map((a) => (
                <li key={a}>{a}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="section" id="call-for-papers" aria-labelledby="cfp-title">
        <div className="container">
          <SectionHeading
            eyebrow="Call for papers"
            title="Paper submission"
            id="cfp-title"
            intro={
              <p>
                Contributed research papers are invited across all three tracks. The call for papers opens on{' '}
                <strong>{cfp.display}</strong>, and the final paper submission deadline is{' '}
                <strong>{finalPaper.display}</strong>.
              </p>
            }
          />

          <div className="cfp-grid">
            <div className="cfp-grid__main">
              <IntegrationStatus kind="submission" />

              <h3 className="sub-heading">How to submit</h3>
              <ol className="steps">
                <li>
                  <span className="steps__title">Choose a track</span>
                  <span>Identify the track and topic that best fits your work from the lists above.</span>
                </li>
                <li>
                  <span className="steps__title">Prepare your paper</span>
                  <span>Follow the author guidelines and paper template once they are published on this page.</span>
                </li>
                <li>
                  <span className="steps__title">Submit before the deadline</span>
                  <span>
                    Submit through the official submission system by {finalPaper.display}.
                  </span>
                </li>
                <li>
                  <span className="steps__title">Register</span>
                  <span>
                    Register for the conference — see the{' '}
                    <Link to="/registration">registration page</Link> for fees and deadlines.
                  </span>
                </li>
              </ol>
            </div>

            <aside className="cfp-grid__side" aria-labelledby="docs-title">
              <h3 id="docs-title" className="sub-heading">
                Documents
              </h3>
              <ul className="doc-list">
                {documents.map((d) => (
                  <li key={d.id}>
                    <Icon name="file" size={20} />
                    <div>
                      {d.href ? (
                        <a href={d.href} download>
                          {d.title} <span className="doc-list__type">PDF</span>
                        </a>
                      ) : (
                        <span className="doc-list__title">{d.title}</span>
                      )}
                      <span className="doc-list__desc">{d.description}</span>
                      {!d.href ? <span className="badge">Not yet published</span> : null}
                    </div>
                  </li>
                ))}
              </ul>
              <PendingNotice title="Publication information" compact>
                <p>
                  Details of publication of accepted papers will be announced here once confirmed by the organizers.
                </p>
              </PendingNotice>
            </aside>
          </div>
        </div>
      </section>
    </>
  );
}
