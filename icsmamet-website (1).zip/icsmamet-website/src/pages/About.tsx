import { Link } from 'react-router-dom';
import { metaFor } from '../app/siteMap';
import { CampusImage } from '../components/CampusImage';
import { Icon } from '../components/Icon';
import { PageHero } from '../components/PageHero';
import { SectionHeading } from '../components/SectionHeading';
import { conference, imperative, institution, overview } from '../data/conference';
import { tracks } from '../data/tracks';
import { usePageMeta } from '../hooks/usePageMeta';

export default function About() {
  const meta = metaFor('/about');
  usePageMeta(meta);

  return (
    <>
      <PageHero
        meta={meta}
        title="About the conference"
        lead={<p>{overview.context}</p>}
        aside={
          <dl className="hero-facts">
            <div>
              <dt>Dates</dt>
              <dd>{conference.dates.display}</dd>
            </div>
            <div>
              <dt>Venue</dt>
              <dd>{conference.venueLine}</dd>
            </div>
            <div>
              <dt>Organized by</dt>
              <dd>{conference.host.short}</dd>
            </div>
          </dl>
        }
      />

      <section className="section" aria-labelledby="overview-title">
        <div className="container split">
          <SectionHeading eyebrow="Overview" title="Purpose of ICSMAMET" id="overview-title" />
          <div className="prose">
            <p className="prose-lead">{overview.aim}</p>
            <p>{overview.format}</p>
          </div>
        </div>
      </section>

      <section className="section section--ivory" aria-labelledby="objectives-title">
        <div className="container">
          <SectionHeading eyebrow="Objectives" title="What the conference sets out to do" id="objectives-title" />
          <ol className="objective-grid">
            {overview.objectives.map((o, i) => (
              <li key={o}>
                <span className="objective-grid__num" aria-hidden="true">
                  {String(i + 1).padStart(2, '0')}
                </span>
                <p>{o}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="section" aria-labelledby="relevance-title">
        <div className="container">
          <SectionHeading
            eyebrow="Relevance"
            title={imperative.title}
            id="relevance-title"
            intro={<p>{imperative.body}</p>}
          />
          <div className="relevance-grid">
            {tracks.map((t) => (
              <Link key={t.id} to={`/themes#${t.id}`} className="relevance-card">
                <span className="relevance-card__num">Track {String(t.number).padStart(2, '0')}</span>
                <span className="relevance-card__title">{t.title}</span>
                <span className="relevance-card__focus">{t.focus}</span>
                <Icon name="arrowRight" size={18} />
              </Link>
            ))}
          </div>
          <div className="about-meta">
            <div>
              <h3 className="about-meta__title">Who should participate</h3>
              <ul className="chip-list">
                {overview.audience.map((a) => (
                  <li key={a}>{a}</li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="about-meta__title">Contributions covering</h3>
              <ul className="chip-list">
                {overview.coverage.map((a) => (
                  <li key={a}>{a} developments</li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="about-meta__title">Programme format</h3>
              <ul className="chip-list">
                {overview.formatItems.map((a) => (
                  <li key={a}>{a}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="section section--green" id="host" aria-labelledby="host-title">
        <div className="container">
          <SectionHeading eyebrow="Organizing institution" title={institution.heading} id="host-title" tone="dark" />
          <div className="institution">
            <div className="institution__text">
              {institution.paragraphs.slice(0, 2).map((p) => (
                <p key={p.slice(0, 24)}>{p}</p>
              ))}
            </div>
            <figure className="institution__figure">
              <CampusImage sizes="(min-width: 1000px) 560px, 100vw" />
              <figcaption>VNR VJIET campus, Bachupally, Hyderabad</figcaption>
            </figure>
          </div>

          <dl className="stat-grid">
            {institution.facts.map((f) => (
              <div key={f.label}>
                <dt>{f.label}</dt>
                <dd>{f.value}</dd>
              </div>
            ))}
          </dl>

          <div className="institution__lower">
            <div>
              <h3 className="sub-heading sub-heading--light">Academic programmes</h3>
              <ul className="program-list">
                {institution.programs.map((p) => (
                  <li key={p.level}>
                    <span className="program-list__level">{p.level}</span>
                    <span>{p.detail}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="sub-heading sub-heading--light">Recognition</h3>
              <ul className="check-list">
                {institution.recognitions.map((r) => (
                  <li key={r}>
                    <Icon name="check" size={16} /> {r}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="institution__text institution__text--wide">
            {institution.paragraphs.slice(2).map((p) => (
              <p key={p.slice(0, 24)}>{p}</p>
            ))}
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="venue-title">
        <div className="container split">
          <SectionHeading eyebrow="Venue" title="Conference venue" id="venue-title" />
          <div className="prose">
            <p className="prose-lead">
              The conference will be held at {conference.host.short}, {conference.host.locality}, {conference.host.city},
              from {conference.dates.display}.
            </p>
            <p>
              Accommodation is available on campus on a paid basis, subject to availability and prior request.
            </p>
            <div className="inline-links">
              <Link className="link-arrow" to="/accommodation">
                Accommodation <Icon name="arrowRight" size={16} />
              </Link>
              <Link className="link-arrow" to="/contact#venue">
                Map &amp; directions <Icon name="arrowRight" size={16} />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
