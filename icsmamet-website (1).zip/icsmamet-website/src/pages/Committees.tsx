import { metaFor } from '../app/siteMap';
import { CommitteeLeadership, CommitteeList } from '../components/CommitteeList';
import { PageHero } from '../components/PageHero';
import { SectionHeading } from '../components/SectionHeading';
import { committees } from '../data/committees';
import { conference } from '../data/conference';
import { usePageMeta } from '../hooks/usePageMeta';

export default function Committees() {
  const meta = metaFor('/committees');
  usePageMeta(meta);
  const leadership = committees.filter((c) => c.layout === 'leadership');
  const lists = committees.filter((c) => c.layout === 'list');

  return (
    <>
      <PageHero
        meta={meta}
        title="Conference committees"
        lead={<p>{conference.shortName} is organized by {conference.host.short}, Hyderabad, under the patronage of Vignana Jyothi.</p>}
      />

      <section className="section" aria-labelledby="leadership-title">
        <div className="container">
          <SectionHeading eyebrow="Patrons & leadership" title="Patrons and conference leadership" id="leadership-title" />
          <CommitteeLeadership groups={leadership} />
        </div>
      </section>

      <section className="section section--ivory" aria-labelledby="committees-title">
        <div className="container">
          <SectionHeading eyebrow="Committees" title="Organizing, editorial and advisory committees" id="committees-title" />
          <nav className="jump-links" aria-label="Jump to committee">
            {lists.map((g) => (
              <a key={g.id} href={`#${g.id}`}>
                {g.title}
              </a>
            ))}
          </nav>
          <div className="committee-grid">
            {lists.map((g) => (
              <CommitteeList key={g.id} group={g} />
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
