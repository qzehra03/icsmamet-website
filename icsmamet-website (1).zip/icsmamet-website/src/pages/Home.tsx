import { Link } from 'react-router-dom';
import { metaFor } from '../app/siteMap';
import { CampusImage } from '../components/CampusImage';
import { RegisterAction, SubmitPaperAction } from '../components/ConferenceActions';
import { DeadlineTimeline } from '../components/DeadlineTimeline';
import { Hero } from '../components/Hero';
import { Icon } from '../components/Icon';
import { SectionHeading } from '../components/SectionHeading';
import { SpeakerCard } from '../components/SpeakerCard';
import { TrackCard } from '../components/TrackCard';
import { conference, imperative, institution, overview } from '../data/conference';
import { speakers } from '../data/speakers';
import { tracks } from '../data/tracks';
import { usePageMeta } from '../hooks/usePageMeta';

export default function Home() {
  usePageMeta(metaFor('/'));

  return (
    <>
      <Hero />

      {/* What & why */}
      <section className="section section--ivory" aria-labelledby="imperative-title">
        <div className="container imperative">
          <div className="imperative__intro">
            <SectionHeading eyebrow={imperative.eyebrow} title={imperative.title} id="imperative-title" />
            <p className="prose-lead">{imperative.body}</p>
            <p className="prose">{overview.context}</p>
          </div>
          <div className="imperative__cols">
            {imperative.pillars.map((p, i) => (
              <div key={p.title} className="pillar">
                <span className="pillar__num" aria-hidden="true">
                  {String(i + 1).padStart(2, '0')}
                </span>
                <h3 className="pillar__title">{p.title}</h3>
                <p>{p.body}</p>
              </div>
            ))}
            <div className="pillar pillar--audience">
              <span className="pillar__num" aria-hidden="true">
                03
              </span>
              <h3 className="pillar__title">Who should participate</h3>
              <ul className="chip-list">
                {overview.audience.map((a) => (
                  <li key={a}>{a}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Tracks */}
      <section className="section" aria-labelledby="tracks-title">
        <div className="container">
          <div className="section-row">
            <SectionHeading
              eyebrow="Technical programme"
              title="Three research tracks"
              id="tracks-title"
              intro={<p>{overview.format}</p>}
            />
            <Link className="link-arrow" to="/themes">
              All themes &amp; call for papers <Icon name="arrowRight" size={16} />
            </Link>
          </div>
          <div className="track-grid">
            {tracks.map((t) => (
              <TrackCard key={t.id} track={t} variant="preview" />
            ))}
          </div>
        </div>
      </section>

      {/* Speakers */}
      <section className="section section--stone" aria-labelledby="speakers-title">
        <div className="container">
          <div className="section-row">
            <SectionHeading eyebrow="Invited speakers" title="Perspectives from research and industry" id="speakers-title" />
            <Link className="link-arrow" to="/speakers">
              All invited speakers <Icon name="arrowRight" size={16} />
            </Link>
          </div>
          <div className="speaker-grid speaker-grid--compact">
            {speakers.map((s) => (
              <SpeakerCard key={s.id} speaker={s} variant="compact" />
            ))}
          </div>
        </div>
      </section>

      {/* Dates + CTA */}
      <section className="section" aria-labelledby="dates-title">
        <div className="container dates-cta">
          <div>
            <SectionHeading
              eyebrow="Important dates"
              title="Plan your participation"
              id="dates-title"
              intro={<p>Key milestones from the call for papers to the conference days.</p>}
            />
            <div className="dates-cta__actions">
              <SubmitPaperAction />
              <RegisterAction />
            </div>
            <Link className="link-arrow" to="/important-dates">
              Full timeline <Icon name="arrowRight" size={16} />
            </Link>
          </div>
          <DeadlineTimeline variant="compact" />
        </div>
      </section>

      {/* Host */}
      <section className="section section--green" aria-labelledby="host-title">
        <div className="container host">
          <div className="host__media">
            <CampusImage className="host__img" />
          </div>
          <div className="host__text">
            <SectionHeading eyebrow="Host institution" title={institution.heading} id="host-title" tone="dark" />
            <p>{institution.paragraphs[0]}</p>
            <dl className="fact-row">
              {institution.facts.slice(0, 3).map((f) => (
                <div key={f.label}>
                  <dt>{f.label}</dt>
                  <dd>{f.value}</dd>
                </div>
              ))}
            </dl>
            <Link className="link-arrow link-arrow--light" to="/about#host">
              More about {conference.host.short} <Icon name="arrowRight" size={16} />
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}
