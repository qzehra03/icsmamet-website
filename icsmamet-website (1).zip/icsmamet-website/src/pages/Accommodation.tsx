import { Link } from 'react-router-dom';
import { metaFor } from '../app/siteMap';
import { EnquiryForm, type FieldConfig } from '../components/EnquiryForm';
import { Icon } from '../components/Icon';
import { MapEmbed } from '../components/MapEmbed';
import { PageHero } from '../components/PageHero';
import { PendingNotice } from '../components/PendingNotice';
import { SectionHeading } from '../components/SectionHeading';
import { accommodation, conference } from '../data/conference';
import { contacts } from '../data/contact';
import { usePageMeta } from '../hooks/usePageMeta';

const fields: FieldConfig[] = [
  { name: 'name', label: 'Full name', required: true, autoComplete: 'name', span: 'half' },
  { name: 'email', label: 'Email', type: 'email', required: true, autoComplete: 'email', span: 'half' },
  { name: 'phone', label: 'Phone', type: 'tel', autoComplete: 'tel', span: 'half' },
  { name: 'affiliation', label: 'Institution / organization', autoComplete: 'organization', span: 'half' },
  {
    name: 'preference',
    label: 'Accommodation preference',
    type: 'select',
    required: true,
    options: ['VNR VJIET hostel', 'VNR VJIET guest house', 'Either'],
    span: 'half',
  },
  { name: 'guests', label: 'Number of guests', type: 'number', min: '1', span: 'half' },
  { name: 'arrival', label: 'Arrival date', type: 'date', required: true, span: 'half' },
  { name: 'departure', label: 'Departure date', type: 'date', required: true, span: 'half', notBefore: 'arrival' },
  { name: 'notes', label: 'Additional requirements', type: 'textarea' },
];

export default function Accommodation() {
  const meta = metaFor('/accommodation');
  usePageMeta(meta);

  return (
    <>
      <PageHero meta={meta} title="Accommodation" lead={<p>{accommodation.summary}</p>} />

      <section className="section" aria-labelledby="options-title">
        <div className="container">
          <SectionHeading eyebrow="On campus" title="Accommodation at VNR VJIET" id="options-title" />
          <div className="option-grid">
            {accommodation.options.map((o) => (
              <div key={o.name} className="option-card">
                <Icon name="bed" size={26} />
                <h3>{o.name}</h3>
                <p>{o.basis}</p>
              </div>
            ))}
            <PendingNotice title="Charges and check-in details">
              <p>
                Room charges, check-in rules and availability will be published here once confirmed by the organizers.
              </p>
            </PendingNotice>
          </div>
        </div>
      </section>

      <section className="section section--ivory" id="request" aria-labelledby="request-title">
        <div className="container form-layout">
          <div>
            <SectionHeading
              eyebrow="Booking request"
              title="Request accommodation"
              id="request-title"
              intro={
                <p>
                  Accommodation is allocated subject to availability and prior request. Send your request to the
                  conveners with your dates and preference; they will confirm availability and charges.
                </p>
              }
            />
            <ul className="contact-mini">
              {contacts.map((c) => (
                <li key={c.email}>
                  <span className="contact-mini__name">{c.name}</span>
                  <a href={`mailto:${c.email}`}>
                    <Icon name="mail" size={15} /> {c.email}
                  </a>
                  <a href={`tel:${c.phoneE164}`}>
                    <Icon name="phone" size={15} /> {c.phone}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div className="form-card">
            <EnquiryForm
              formName="accommodation-request"
              subject={(v) => `${conference.shortName} — Accommodation request${v.name ? ` — ${v.name}` : ''}`}
              fields={fields}
              submitLabel="Send accommodation request"
            />
          </div>
        </div>
      </section>

      <section className="section" aria-labelledby="travel-title">
        <div className="container split">
          <div>
            <SectionHeading eyebrow="Travel" title="Getting to the venue" id="travel-title" />
            <p className="prose">{conference.venueLine}</p>
            <PendingNotice title="Travel information" compact>
              <p>Detailed travel guidance will be published here. For assistance, please <Link to="/contact">contact the organizers</Link>.</p>
            </PendingNotice>
          </div>
          <MapEmbed />
        </div>
      </section>
    </>
  );
}
