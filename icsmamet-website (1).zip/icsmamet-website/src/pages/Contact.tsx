import { Link } from 'react-router-dom';
import { metaFor } from '../app/siteMap';
import { EnquiryForm, type FieldConfig } from '../components/EnquiryForm';
import { Icon } from '../components/Icon';
import { MapEmbed } from '../components/MapEmbed';
import { PageHero } from '../components/PageHero';
import { SectionHeading } from '../components/SectionHeading';
import { conference } from '../data/conference';
import { contacts } from '../data/contact';
import { usePageMeta } from '../hooks/usePageMeta';

const topics = ['Paper submission', 'Registration', 'Accommodation', 'Invited talks & programme', 'General enquiry'];

const fields: FieldConfig[] = [
  { name: 'name', label: 'Full name', required: true, autoComplete: 'name', span: 'half' },
  { name: 'email', label: 'Email', type: 'email', required: true, autoComplete: 'email', span: 'half' },
  { name: 'affiliation', label: 'Institution / organization', autoComplete: 'organization', span: 'half' },
  { name: 'topic', label: 'Topic', type: 'select', required: true, options: topics, span: 'half' },
  { name: 'message', label: 'Message', type: 'textarea', required: true },
];

export default function Contact() {
  const meta = metaFor('/contact');
  usePageMeta(meta);

  return (
    <>
      <PageHero meta={meta} title="Contact the organizers" lead={<p>For queries about papers, registration or accommodation, please contact the conference conveners.</p>} />

      <section className="section" aria-labelledby="contacts-title">
        <div className="container">
          <SectionHeading eyebrow="Conveners" title="Conference contacts" id="contacts-title" />
          <div className="contact-grid">
            {contacts.map((c) => (
              <article key={c.email} className="contact-card">
                <p className="contact-card__role">{c.role}</p>
                <h3 className="contact-card__name">{c.name}</h3>
                <p className="contact-card__org">{conference.host.short}, {conference.host.city}</p>
                <ul>
                  <li>
                    <a href={`mailto:${c.email}`}>
                      <Icon name="mail" size={18} />
                      <span>
                        <span className="visually-hidden">Email: </span>
                        {c.email}
                      </span>
                    </a>
                  </li>
                  <li>
                    <a href={`tel:${c.phoneE164}`}>
                      <Icon name="phone" size={18} />
                      <span>
                        <span className="visually-hidden">Mobile: </span>
                        {c.phone}
                      </span>
                    </a>
                  </li>
                </ul>
              </article>
            ))}
            <div className="contact-card contact-card--links">
              <p className="contact-card__role">Assistance</p>
              <h3 className="contact-card__name">Quick links</h3>
              <ul className="link-list">
                <li>
                  <Link to="/themes#call-for-papers">Paper submission <Icon name="arrowRight" size={15} /></Link>
                </li>
                <li>
                  <Link to="/registration">Registration &amp; fees <Icon name="arrowRight" size={15} /></Link>
                </li>
                <li>
                  <Link to="/accommodation#request">Accommodation request <Icon name="arrowRight" size={15} /></Link>
                </li>
                <li>
                  <Link to="/important-dates">Important dates <Icon name="arrowRight" size={15} /></Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="section section--ivory" id="enquiry" aria-labelledby="enquiry-title">
        <div className="container form-layout">
          <SectionHeading
            eyebrow="Enquiry"
            title="Send a message"
            id="enquiry-title"
            intro={<p>Your message goes to both conveners. Please include your paper ID, if you have one.</p>}
          />
          <div className="form-card">
            <EnquiryForm
              formName="contact"
              subject={(v) => `${conference.shortName} — ${v.topic || 'Enquiry'}${v.name ? ` — ${v.name}` : ''}`}
              fields={fields}
              submitLabel="Send message"
            />
          </div>
        </div>
      </section>

      <section className="section" id="venue" aria-labelledby="venue-title">
        <div className="container">
          <SectionHeading eyebrow="Venue" title={conference.host.short} id="venue-title" intro={<p>{conference.host.name}, {conference.host.locality}, {conference.host.city}, {conference.host.region}, {conference.host.country}.</p>} />
          <MapEmbed />
        </div>
      </section>
    </>
  );
}
