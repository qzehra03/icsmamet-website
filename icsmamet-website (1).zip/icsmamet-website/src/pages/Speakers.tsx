import { Link } from 'react-router-dom';
import { metaFor } from '../app/siteMap';
import { Icon } from '../components/Icon';
import { PageHero } from '../components/PageHero';
import { SpeakerCard } from '../components/SpeakerCard';
import { speakers } from '../data/speakers';
import { usePageMeta } from '../hooks/usePageMeta';

export default function Speakers() {
  const meta = metaFor('/speakers');
  usePageMeta(meta);

  return (
    <>
      <PageHero
        meta={meta}
        title="Invited speakers"
        lead={
          <p>
            The programme features plenary and invited lectures by researchers and industry leaders from India and
            abroad.
          </p>
        }
      />
      <section className="section" aria-label="Speaker profiles">
        <div className="container">
          <div className="speaker-grid">
            {speakers.map((s) => (
              <SpeakerCard key={s.id} speaker={s} variant="full" headingLevel="h2" />
            ))}
          </div>
          <p className="section-note">
            <Icon name="info" size={16} />
            <span>
              Speaker biographies, research expertise and lecture titles will be added as they are confirmed. See also the{' '}
              <Link to="/committees#advisory">Advisory Committee</Link>.
            </span>
          </p>
        </div>
      </section>
    </>
  );
}
