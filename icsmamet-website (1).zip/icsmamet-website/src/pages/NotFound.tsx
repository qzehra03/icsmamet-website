import { Link } from 'react-router-dom';
import { navPages, notFoundMeta } from '../app/siteMap';
import { usePageMeta } from '../hooks/usePageMeta';

export default function NotFound() {
  usePageMeta(notFoundMeta);
  return (
    <section className="not-found" aria-labelledby="page-title">
      <div className="page-hero__texture" aria-hidden="true" />
      <div className="container not-found__inner">
        <p className="eyebrow eyebrow--on-dark">Error 404</p>
        <h1 id="page-title" className="page-hero__title" tabIndex={-1}>
          Page not found
        </h1>
        <p className="page-hero__lead">The page you requested does not exist or may have moved.</p>
        <Link className="btn btn--gold" to="/">
          Go to the homepage
        </Link>
        <ul className="not-found__links">
          {navPages.map((p) => (
            <li key={p.path}>
              <Link to={p.path}>{p.label}</Link>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
