import { metaFor } from '../app/siteMap';
import { RegisterAction, SubmitPaperAction } from '../components/ConferenceActions';
import { DeadlineTimeline } from '../components/DeadlineTimeline';
import { Icon } from '../components/Icon';
import { PageHero } from '../components/PageHero';
import { conference } from '../data/conference';
import { deadlines, deadlineTimeZone } from '../data/deadlines';
import { usePageMeta } from '../hooks/usePageMeta';

/** Build a downloadable .ics calendar file for the conference days (client-side, no server). */
function conferenceIcs(): string {
  const conf = deadlines.find((d) => d.id === 'conference')!;
  const start = conf.date.replace(/-/g, '');
  const endDate = new Date(`${conf.endDate ?? conf.date}T00:00:00Z`);
  endDate.setUTCDate(endDate.getUTCDate() + 1); // DTEND is exclusive for all-day events
  const end = endDate.toISOString().slice(0, 10).replace(/-/g, '');
  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//ICSMAMET 2027//Conference website//EN',
    'CALSCALE:GREGORIAN',
    'BEGIN:VEVENT',
    `UID:icsmamet-2027-conference@icsmamet`,
    'DTSTAMP:20261001T000000Z',
    `DTSTART;VALUE=DATE:${start}`,
    `DTEND;VALUE=DATE:${end}`,
    `SUMMARY:${conference.shortName}`,
    `DESCRIPTION:${conference.name}`,
    `LOCATION:${conference.venueLine.replace(/,/g, '\\,')}`,
    'END:VEVENT',
    'END:VCALENDAR',
  ];
  return `data:text/calendar;charset=utf-8,${encodeURIComponent(lines.join('\r\n'))}`;
}

export default function ImportantDates() {
  const meta = metaFor('/important-dates');
  usePageMeta(meta);

  return (
    <>
      <PageHero
        meta={meta}
        title="Important dates"
        lead={<p>Deadlines for paper submission and registration, and the conference days.</p>}
        aside={
          <dl className="hero-facts">
            <div>
              <dt>Conference days</dt>
              <dd>{conference.dates.display}</dd>
            </div>
            <div>
              <dt>Venue</dt>
              <dd>
                {conference.host.short}, {conference.host.city}
              </dd>
            </div>
          </dl>
        }
      />

      <section className="section" aria-labelledby="timeline-title">
        <div className="container dates-page">
          <div>
            <h2 id="timeline-title" className="visually-hidden">
              Timeline
            </h2>
            <DeadlineTimeline variant="full" />
            <p className="section-note">
              <Icon name="info" size={16} />
              {deadlineTimeZone
                ? `All deadlines are in ${deadlineTimeZone}.`
                : 'The time zone for deadlines and any extensions will be announced on this page.'}
            </p>
          </div>
          <aside className="dates-page__side" aria-label="Actions">
            <div className="side-card">
              <h3 className="sub-heading">Take part</h3>
              <div className="stack">
                <SubmitPaperAction />
                <RegisterAction />
              </div>
            </div>
            <div className="side-card">
              <h3 className="sub-heading">Add to calendar</h3>
              <p>Save the conference days ({conference.dates.display}) to your calendar.</p>
              <a className="btn btn--outline" href={conferenceIcs()} download="icsmamet-2027.ics">
                <Icon name="calendar" size={16} /> Download .ics
              </a>
            </div>
          </aside>
        </div>
      </section>
    </>
  );
}
