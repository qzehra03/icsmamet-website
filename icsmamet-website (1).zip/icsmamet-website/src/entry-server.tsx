/**
 * Build-time renderer used by scripts/prerender.mjs to write static HTML for
 * every route. It is never shipped to the browser.
 */
import { StrictMode } from 'react';
import { renderToString } from 'react-dom/server';
import { StaticRouter } from 'react-router-dom/server';
import { App } from './app/App';
import { metaFor, notFoundMeta, pages } from './app/siteMap';
import { conference } from './data/conference';
import { contacts } from './data/contact';

export function render(url: string): string {
  return renderToString(
    <StrictMode>
      <StaticRouter location={url}>
        <App />
      </StaticRouter>
    </StrictMode>,
  );
}

/** Structured data for search engines (schema.org Event). */
export function eventJsonLd(siteUrl: string | null) {
  return {
    '@context': 'https://schema.org',
    '@type': 'Event',
    name: `${conference.name} (${conference.shortName})`,
    alternateName: conference.shortName,
    description: conference.strapline,
    startDate: conference.dates.start,
    endDate: conference.dates.end,
    eventAttendanceMode: 'https://schema.org/OfflineEventAttendanceMode',
    eventStatus: 'https://schema.org/EventScheduled',
    ...(siteUrl ? { url: siteUrl + '/' } : {}),
    location: {
      '@type': 'Place',
      name: conference.host.name,
      address: {
        '@type': 'PostalAddress',
        addressLocality: `${conference.host.locality}, ${conference.host.city}`,
        addressRegion: conference.host.region,
        addressCountry: 'IN',
      },
    },
    organizer: {
      '@type': 'CollegeOrUniversity',
      name: conference.host.name,
      alternateName: conference.host.short,
      email: contacts[0].email,
    },
  };
}

export { metaFor, notFoundMeta, pages };
