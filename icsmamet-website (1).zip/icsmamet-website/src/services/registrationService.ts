/**
 * Integration layer for registration, paper submission, forms and maps.
 *
 * The site is static-first: every external workflow is configured through a
 * build-time environment variable (see .env.example). When a destination is not
 * configured, callers receive `null` and must show an honest fallback — a
 * pre-filled email to the conveners — instead of a button that appears to work.
 */

import { conference } from '../data/conference';
import { contactEmails } from '../data/contact';

function clean(value: string | undefined): string | null {
  const v = (value ?? '').trim();
  if (!v) return null;
  try {
    const url = new URL(v);
    return url.protocol === 'https:' || url.protocol === 'http:' ? url.toString() : null;
  } catch {
    return null;
  }
}

export const integrations = {
  registrationUrl: clean(import.meta.env.VITE_REGISTRATION_URL),
  submissionUrl: clean(import.meta.env.VITE_SUBMISSION_URL),
  contactFormEndpoint: clean(import.meta.env.VITE_CONTACT_FORM_ENDPOINT),
  mapUrl: clean(import.meta.env.VITE_MAP_URL),
} as const;

export const isRegistrationOpen = (): boolean => integrations.registrationUrl !== null;
export const isSubmissionOpen = (): boolean => integrations.submissionUrl !== null;

/** Build a mailto: link to both conveners with an optional subject/body. */
export function mailtoConveners(subject: string, body?: string): string {
  const params = new URLSearchParams();
  params.set('subject', subject);
  if (body) params.set('body', body);
  // URLSearchParams encodes spaces as "+", which some mail clients show literally.
  const query = params.toString().replace(/\+/g, '%20');
  return `mailto:${contactEmails.join(',')}?${query}`;
}

const mapQuery = `VNR Vignana Jyothi Institute of Engineering and Technology, ${conference.host.locality}, ${conference.host.city}`;

export const maps = {
  /** Keyless Google Maps embed for the institute. */
  embedUrl: `https://www.google.com/maps?q=${encodeURIComponent(mapQuery)}&output=embed`,
  /** Opens Google Maps (app or web). Uses the official link when configured. */
  openUrl:
    integrations.mapUrl ??
    `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(mapQuery)}`,
  directionsUrl: `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(mapQuery)}`,
};

export interface FormPayload {
  formName: string;
  subject: string;
  fields: Record<string, string>;
}

export type SubmitResult = { mode: 'sent' } | { mode: 'mailto'; href: string };

/** Format form fields as a readable plain-text email body. */
export function formatBody(fields: Record<string, string>): string {
  return Object.entries(fields)
    .filter(([, v]) => v.trim() !== '')
    .map(([k, v]) => (v.includes('\n') ? `${k}:\n${v}` : `${k}: ${v}`))
    .join('\n');
}

/**
 * Submit a form. With an endpoint configured, POSTs JSON; otherwise returns a
 * mailto: link that opens the visitor's email client with everything pre-filled.
 */
export async function submitForm(payload: FormPayload): Promise<SubmitResult> {
  const endpoint = integrations.contactFormEndpoint;
  if (!endpoint) {
    return { mode: 'mailto', href: mailtoConveners(payload.subject, formatBody(payload.fields)) };
  }
  const res = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ form: payload.formName, subject: payload.subject, ...payload.fields }),
  });
  if (!res.ok) throw new Error(`Form service responded with ${res.status}`);
  return { mode: 'sent' };
}
