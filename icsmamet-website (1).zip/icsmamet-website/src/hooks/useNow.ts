import { useEffect, useState } from 'react';

/**
 * Returns the current date only after hydration (null during prerender and the
 * first client render), so date-dependent UI never causes a hydration mismatch.
 */
export function useNow(): Date | null {
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    setNow(new Date());
  }, []);
  return now;
}
