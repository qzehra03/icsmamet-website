import { useEffect } from 'react';
import type { PageMeta } from '../app/siteMap';

function setMeta(selector: string, attr: 'content' | 'href', value: string) {
  const el = document.head.querySelector<HTMLMetaElement | HTMLLinkElement>(selector);
  if (el) el.setAttribute(attr, value);
}

/**
 * Keeps <title>, description, canonical and social tags in sync during client-side
 * navigation. The prerender step writes the same values into each page's static HTML.
 */
export function usePageMeta(meta: PageMeta) {
  useEffect(() => {
    document.title = meta.title;
    const url = window.location.origin + (meta.path === '/404' ? window.location.pathname : meta.path);
    setMeta('meta[name="description"]', 'content', meta.description);
    setMeta('meta[property="og:title"]', 'content', meta.title);
    setMeta('meta[property="og:description"]', 'content', meta.description);
    setMeta('meta[property="og:url"]', 'content', url);
    setMeta('meta[name="twitter:title"]', 'content', meta.title);
    setMeta('meta[name="twitter:description"]', 'content', meta.description);
    setMeta('link[rel="canonical"]', 'href', url);
  }, [meta]);
}
