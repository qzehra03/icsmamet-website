/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_REGISTRATION_URL?: string;
  readonly VITE_SUBMISSION_URL?: string;
  readonly VITE_CONTACT_FORM_ENDPOINT?: string;
  readonly VITE_MAP_URL?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
