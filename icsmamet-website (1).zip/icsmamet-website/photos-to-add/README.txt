Drop original campus photos here, then run:  npm run photos
The optimized versions are written to public/images/campus/.
This folder is not deployed.
